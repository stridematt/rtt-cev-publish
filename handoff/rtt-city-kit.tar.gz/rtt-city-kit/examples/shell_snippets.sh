#!/usr/bin/env bash
# Rally Takes the Train: shell snippets. Not meant to run top to bottom; copy the block you need.

# ---------- A. Set up the kit in a cloud workspace (Python 3.12+) ----------
cp -r rtt-city-kit /home/claude/rtt && cd /home/claude/rtt/pipeline && mkdir -p ev out work
# Fresh list of live pages (used to avoid slug clashes). The kit has a snapshot in tools/live.json; refresh it when you can:
gh repo clone stridematt/sitemaps /home/claude/stridematt/sitemaps -- --depth 1 && export RTT_LIVE_JSON=/home/claude/stridematt/sitemaps/tools/truth/live.json
# or: export RTT_LIVE_JSON=../tools/live.json

# ---------- B. Events directory check (ON MATT'S MAC via device_bash; never print the token) ----------
cd $HOME/mnt/sa/registry && set -a && . ./.env >/dev/null 2>&1; set +a
python3 registry.py check --name "Christmas in Canton" --city Canton --cc ga --date 2026-12-11
#  "NEW 0 ..."            -> not in the directory
#  "match: RTT-... | slug" -> already live: check whether it is carded on the right city page, do not rebuild
#  a "match" with a clearly different event (e.g. Santa Storytime for Breakfast with Santa) is a false match: use --confirm-new on add

# ---------- C. Build ----------
RUN=work/canton-run        # one folder per run
mkdir -p $RUN              # write $RUN/facts.json by hand (see examples/facts_example.json)
for s in canton-ga kennesaw-ga; do mkdir -p work/$s; [ -f work/$s/$s.html ] || cp ../tools/empty_city.html work/$s/$s.html; done
python3 disc_build.py $RUN/facts.json canton-ga $RUN/cards.json          # 2nd arg is ignored when facts carry "page"
python3 us_city.py multi $RUN/cards.json                                  # ev/<slug>.json + out/<slug>/page.html
# write $RUN/tweaks.json (see examples/tweaks_example.json), then:
python3 ../tools/tweak_pages.py $RUN/facts.json $RUN/tweaks.json          # venue fix, Where-is fix, extra content, rebuild, source line
python3 ../tools/uniq.py christmas-in-canton-ga glimmer-and-glee-drone-show-in-kennesaw-ga
#  every line must show >= 60.0% and [] for issues. "own website" is fine only when the url really is the host's site.
A=$(python3 ../tools/split_cards.py $RUN/facts.json $RUN/cards.json)
python3 mkbundle_us.py $RUN/bundle.json.gz winterfest-seattle-wa $A     # upload this file in the browser (max 3.8 MB)

# Empty price check (hold the event instead of publishing):
grep -l 'Admission: \.' out/*/page.html

# ---------- D. Directory add (Mac, after the pages are live and carded) ----------
python3 registry.py add --slug christmas-in-canton-ga --name "Christmas in Canton" --city Canton --cc ga \
  --url https://explorecantonga.com/events/christmas-in-canton-2026/ --date 2026-12-11 --status live --confirm-new
# device_bash calls time out at 180 s: about 10 adds per call.

# ---------- E. Counts (never hand-edit counts) ----------
gh api -X POST repos/stridematt/sitemaps/actions/workflows/quick-counts.yml/dispatches -f ref=main \
  -f 'inputs[pages]=/christmas-events/canton-ga,/christmas-events/kennesaw-ga'
gh run list -R stridematt/sitemaps -w quick-counts.yml -L 3 --json status,conclusion,createdAt
