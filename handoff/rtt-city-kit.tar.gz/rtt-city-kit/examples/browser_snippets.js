/* Rally Takes the Train: browser snippets for the Squarespace admin tab.
 * Run each block with the Chrome javascript tool in a tab on
 *   https://rally-takes-the-train-site.squarespace.com/config/pages   (signed in)
 * Rules for the Chrome tool: never print anything with = ? & % (it blocks the output) -> always .replace(/[=?&%]/g,'_').
 * Write '?format'+'=json' instead of '?format=json' inside code for the same reason.
 * File input: find it with the find tool ("file input #ar-file"), then file_upload the file to that ref.
 */

// ---------- 0. Load the RTTUS library (once per tab) ----------
// Either it is cached:            await RTTUS.boot()
// or upload pipeline/rtt_us_lib_v5.js to #ar-file, then:
(0, eval)(await document.getElementById('ar-file').files[0].text()); await RTTUS.install(); 'RTTUS ready';

// ---------- 1. Publish new event pages from a bundle ----------
// file_upload work/<run>/bundle.json.gz to #ar-file first.
const r = await RTTUS.load();            // {pages, cities, bad:[]}  bad must be empty
window.__pub = null; RTTUS.publish().then(x => window.__pub = x);   // async, takes ~3 s per page
JSON.stringify(r).replace(/[=?&%]/g, '_');

// ---------- 2. Poll the publish result (repeat until not 'pending'; keep each call under 45 s) ----------
await new Promise(r => setTimeout(r, 30000));
(() => { if (!window.__pub) return 'pending'; const P = typeof window.__pub == 'string' ? JSON.parse(window.__pub) : window.__pub;
  const k = Object.keys(P); return k.length + ' pages; bad: ' + k.filter(s => !(P[s].seo == 200 && P[s].live == 200 && P[s].quick)).join(','); })();
// 'EXISTS' for a slug means it was already live: publish never overwrites. Use RTTUS.update() (section 6) for that.

// ---------- 3. City cards: dry run, then save ----------
await RTTUS.tplFrom('roswell-ga');      // needed once per tab: copies a card template from a city page that has cards
const C = ['canton-ga', 'kennesaw-ga'];  // the city pages in the bundle
const out = []; for (const c of C) { let x = await RTTUS.addCards(c); if (typeof x == 'string') x = JSON.parse(x);
  out.push(c + ':' + (x.v && x.v.ok) + ':' + x.N); }   // N = cards,free,paid -> after; ok must be true
out.join(' | ').replace(/[=?&%]/g, '_');

window.__sv = []; (async () => { for (const c of C) { try { let x = await RTTUS.addCards(c, { save: 1 }); if (typeof x == 'string') x = JSON.parse(x);
  window.__sv.push(c + ':' + (x.v && x.v.ok) + ':' + x.N + ':' + (x.saved || x.status || '')); } catch (e) { window.__sv.push(c + ':ERR:' + e.message); } }
  window.__sv.push('DONE'); })(); 'started';
// then poll:  window.__sv.join(' | ').replace(/[=?&%]/g,'_')

// ---------- 4. Check pages are live and carded (same-origin; the cloud shell cannot reach the public site) ----------
const out4 = []; for (const [c, t] of [['canton-ga', 'Christmas in Canton'], ['kennesaw-ga', 'Glimmer and Glee']]) {
  const h = await fetch('/christmas-events/' + c + '?format' + '=json').then(r => r.text()); out4.push(c + ':' + h.includes(t)); }
out4.join(' ');

// ---------- 5. Date audit: publish date today (Pacific) and schema datePublished only ----------
const S = ['christmas-in-canton-ga', 'glimmer-and-glee-drone-show-in-kennesaw-ga'];
const TODAY = new Date().toLocaleDateString('en-CA', { timeZone: 'America/Los_Angeles' });
const bad5 = []; for (const s of S) { const j = await fetch('/christmas-events/' + s + '?format' + '=json').then(r => r.json()); const b = j.item.body;
  const pub = new Date(j.item.publishOn).toLocaleDateString('en-CA', { timeZone: 'America/Los_Angeles' });
  const dp = [...new Set([...b.matchAll(/datePublished.{0,4}(\d{4}-\d\d-\d\d)/g)].map(m => m[1]))];
  let ld = true; for (const m of b.matchAll(/<script type="application\/ld\+json">([\s\S]*?)<\/script>/g)) { try { JSON.parse(m[1]); } catch (e) { ld = false; } }
  if (pub !== TODAY || dp.join() !== TODAY || /dateModified|lastReviewed/.test(b) || !ld) bad5.push(s + ' pub ' + pub + ' dp ' + dp + ' ld ' + ld); }
S.length + ' checked; issues: ' + bad5.join(' | ');

// ---------- 6. Republish existing event pages (after a fix + rebuild) ----------
// file_upload a bundle built from the fixed pages, then:
await RTTUS.load(); window.__up = null; RTTUS.update().then(x => window.__up = x); 'updating';
// poll: const U=typeof window.__up=='string'?JSON.parse(window.__up):window.__up; Object.keys(U).filter(s=>!(U[s].put==200&&U[s].check)).join(',')
// update() backs up each page to IndexedDB rtt_us/backup and keeps the original publish date.

// ---------- 7. Direct edit of any page (a city card fact, schema cleanup) ----------
// Edits BOTH the rendered html and the editor copy (wysiwyg.source): they often differ, so count matches in each.
const slug = 'brookhaven-ga';
const R7 = [['Saturdays, December 5 and 12', 'Saturdays, December 5, 12 and 19']];   // [old, new] pairs, exact text
const j7 = await fetch('/christmas-events/' + slug + '?format' + '=json').then(r => r.json());
const P7 = await fetch('/api/content-items/' + j7.item.id, { credentials: 'include' }).then(r => r.json());
const crumb = (document.cookie.split('; ').find(c => c.startsWith('crumb' + String.fromCharCode(61))) || '').split(String.fromCharCode(61))[1];
const counts = []; P7.body.layout.rows.forEach(row => row.columns.forEach(col => col.blocks.forEach(b => { if (!b.value || !b.value.html) return;
  for (const [a, z] of R7) { counts.push(b.value.html.split(a).length - 1); b.value.html = b.value.html.split(a).join(z);
    if (b.value.wysiwyg && b.value.wysiwyg.source) { counts.push(b.value.wysiwyg.source.split(a).length - 1); b.value.wysiwyg.source = b.value.wysiwyg.source.split(a).join(z); } } })));
// Look at counts BEFORE saving. Then save:
delete P7.pushedServices; delete P7.pendingPushedServices;
const put = await fetch('/api/content-items/' + P7.id, { method: 'PUT', credentials: 'include', headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': crumb }, body: JSON.stringify(P7) });
'counts ' + counts.join(',') + ' put ' + put.status;
// Also check the excerpt and SEO description: JSON.stringify(P7) for the old text, replace in the whole object the same way.
// Never use string.replace with a replacement containing "$" prices ("$15" is read as a capture group): use split/join.

// ---------- 8. Remove dateModified / lastReviewed from an event page's schema ----------
const clean = h => h.replace(/,\s*"dateModified":\s*"[^"]*"/g, '').replace(/"dateModified":\s*"[^"]*",\s*/g, '')
                    .replace(/,\s*"lastReviewed":\s*"[^"]*"/g, '').replace(/"lastReviewed":\s*"[^"]*",\s*/g, '');
// apply clean() to b.value.html and b.value.wysiwyg.source as in section 7, PUT, then rerun section 5.
