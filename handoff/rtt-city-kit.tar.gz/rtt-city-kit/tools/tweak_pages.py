#!/usr/bin/env python3
"""Apply the hand-written fixes and extra content to built event JSONs, then rebuild the pages.

Run from the pipeline folder after `us_city.py multi`:
  python3 ../tools/tweak_pages.py <facts.json> <tweaks.json>

What it always does (fixes known generator bugs), for every slug in tweaks.json:
  - venue name: locations[].name/area, where_short and facts2 'where' use the venue, not the street
  - "Where is" quick answer: "<name> is at <venue>, <address>."
What it does per slug when the tweak has the key:
  kids      list  -> page.kids_do           (what children do there)
  site      list  -> page.on_site           (what is at the event)
  table     list of [label, value] rows, replaces rows with the same label
  about     list of extra paragraphs (sourced facts only)
  faq       list of [question, answer] (added if the question is new)
  when      string -> replaces the "When is ..." quick answer and FAQ answer
  source    string, e.g. "Visit Henry County's events calendar": replaces "<host>'s own website/own site/public website"
            in the JSON (use when the facts came from a city or CVB calendar, not the host's own site)
  org       string -> page.organizer_url (the host's own site, when the facts url is only a calendar)

tweaks.json: {"<event-slug>": {"cand": 9401, "kids": [...], ...}, ...}   ("cand" matches facts.json)
After it runs, it calls build_listed.py for each slug and post_source.py for the slugs that have "source".
"""
import json, sys, os, subprocess

HERE = os.getcwd()
facts = {f["cand"]: f for f in json.load(open(sys.argv[1]))}
tweaks = json.load(open(sys.argv[2]))

for slug, t in tweaks.items():
    path = os.path.join(HERE, "ev", slug + ".json")
    e = json.load(open(path)); p = e["page"]; x = facts[t["cand"]]
    # generator bug 1: street used as the venue name
    for L in p.get("locations") or []:
        L["name"] = L["area"] = x["venue"]
    p["where_short"] = f"{x['venue']}, {x['town']}"
    for r in p.get("facts2") or []:
        if r[0] == "where":
            street = (p.get("locations") or [{}])[0].get("street") or x["address"].split(",")[0]
            r[1] = x["venue"]; r[2] = f"{street}, {x['town']}"
    # generator bug 2: "Where is" repeats the street
    for q in p.get("quick") or []:
        if q[0].startswith("Where is"):
            q[1] = f"{x['name']} is at {x['venue']}, {x['address']}."
    if t.get("kids"): p["kids_do"] = t["kids"]
    if t.get("site"): p["on_site"] = t["site"]
    if t.get("table"):
        keys = {k for k, _ in t["table"]}
        p["table"] = [r for r in p.get("table") or [] if r[0] not in keys] + t["table"]
    for a in t.get("about", []):
        if a not in p["about"]: p["about"].append(a)
    for q in t.get("faq", []):
        if q[0] not in [y[0] for y in p.get("faq") or []]: p.setdefault("faq", []).append(q)
    if t.get("when"):
        for lst in (p.get("quick") or [], p.get("faq") or []):
            for q in lst:
                if q[0].startswith("When is"): q[1] = t["when"]
    if t.get("org"): p["organizer_url"] = t["org"]
    s = json.dumps(e, ensure_ascii=False)
    if t.get("source"):
        host = x["host"]
        for a in (f"{host}'s own website", f"{host}'s own site", f"{host}'s public website",
                  f"{host}' own website", f"{host}' own site", f"{host}' public website"):
            s = s.replace(a, t["source"])
    json.dump(json.loads(s), open(path, "w"), indent=1, ensure_ascii=False)
    subprocess.run(["python3", "build_listed.py", path], check=True, capture_output=True)
    print("tweaked + rebuilt", slug)

src = {s: t["source"] for s, t in tweaks.items() if t.get("source")}
if src:
    json.dump(src, open("/tmp/_post_source.json", "w"))
    subprocess.run(["python3", os.path.join(os.path.dirname(os.path.abspath(__file__)), "post_source.py"), "/tmp/_post_source.json"], check=True)
