import re,glob,html,sys,json
def txt(p):
    b=open(p).read(); b=re.sub(r"<script.*?</script>|<style.*?</style>","",b,flags=re.S); return html.unescape(re.sub(r"<[^>]+>"," ",b))
def grams(t):
    w=re.findall(r"[a-z0-9']+",t.lower()); return set(tuple(w[i:i+5]) for i in range(len(w)-4))
new=sys.argv[1:]; allp=glob.glob('out/*/page.html'); G={p:grams(txt(p)) for p in allp}
bad=re.compile(r"(?i)not stated|see the host page for|check the host's page|no admission price|does not (list|say|give|state)|price not")
for s in new:
    p=f'out/{s}/page.html'; g=G[p]; best=max(((len(g&G[q])/len(g),q) for q in allp if q!=p),default=(0,''))
    t=txt(p); issues=[m.group(0) for m in bad.finditer(t)]+(['dash'] if re.search('[–—]',t) else [])+(['!'] if '!' in t else [])
    ow=[t[max(0,m.start()-60):m.end()+10].replace('\n',' ') for m in re.finditer('own website',t)][:1]
    print(f"{100-100*best[0]:5.1f}% unique vs {best[1].split('/')[1][:40]:40s} {s[:50]} {issues} {ow}")
