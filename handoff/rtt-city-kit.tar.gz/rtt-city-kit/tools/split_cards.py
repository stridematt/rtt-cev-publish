#!/usr/bin/env python3
"""Split the combined cards.json from disc_build.py into one file per city page and print the mkbundle_us.py arguments.
  python3 ../tools/split_cards.py work/<run>/facts.json work/<run>/cards.json
Prints e.g.  canton-ga:work/<run>/cards_canton-ga.json kennesaw-ga:work/<run>/cards_kennesaw-ga.json
"""
import json, sys, os, collections
facts = {f["name"]: f["page"] for f in json.load(open(sys.argv[1]))}
cards = json.load(open(sys.argv[2])); d = os.path.dirname(sys.argv[2]); by = collections.defaultdict(list)
for c in cards: by[facts[c["name"]]].append(c)
args = []
for city, cs in by.items():
    p = os.path.join(d, f"cards_{city}.json"); json.dump(cs, open(p, "w"), indent=1, ensure_ascii=False); args.append(f"{city}:{p}")
print(" ".join(args))
