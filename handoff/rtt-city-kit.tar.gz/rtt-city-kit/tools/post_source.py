#!/usr/bin/env python3
"""Rewrite the template line "We listed X from <Host>'s public website" to the real source, in out/<slug>/page.html.

build_listed.py writes that line from the organizer name, so it is wrong when the facts came from a city or CVB calendar.
Run AFTER every build_listed.py run (a rebuild puts the old wording back), from the pipeline folder:
  python3 ../tools/post_source.py map.json        map.json = {"<slug>": "Visit Henry County's events calendar", ...}
"""
import html, re, sys, json

for slug, src in json.load(open(sys.argv[1])).items():
    f = f"out/{slug}/page.html"; t = open(f).read()
    t, n = re.subn(r" from [^<>]{3,80}?(?:&#x27;|')s? public website", " from " + html.escape(src), t)
    open(f, "w").write(t); print(n, slug)
