#!/usr/bin/env python3
"""One command from cards to a publish bundle for one US city page.

  python3 us_city.py <city-slug> <city name> <cards.json> <city.html>
  e.g. python3 us_city.py raleigh-nc Raleigh work/raleigh/cards.json work/raleigh/raleigh-nc.html

Runs conv.py, enrich_listed.py, the source wording fix, build_listed.py and mkbundle_us.py, then prints a check per page
(words, dashes, leftovers) and the bundle path. Needs Python 3.12+ (cloud workspace).
"""
import json, sys, os, re, glob, html, subprocess, shutil

STATES = {"al":"Alabama","ak":"Alaska","az":"Arizona","ar":"Arkansas","ca":"California","co":"Colorado","ct":"Connecticut","de":"Delaware","dc":"District of Columbia","fl":"Florida","ga":"Georgia","hi":"Hawaii","id":"Idaho","il":"Illinois","in":"Indiana","ia":"Iowa","ks":"Kansas","ky":"Kentucky","la":"Louisiana","me":"Maine","md":"Maryland","ma":"Massachusetts","mi":"Michigan","mn":"Minnesota","ms":"Mississippi","mo":"Missouri","mt":"Montana","ne":"Nebraska","nv":"Nevada","nh":"New Hampshire","nj":"New Jersey","nm":"New Mexico","ny":"New York","nc":"North Carolina","nd":"North Dakota","oh":"Ohio","ok":"Oklahoma","or":"Oregon","pa":"Pennsylvania","ri":"Rhode Island","sc":"South Carolina","sd":"South Dakota","tn":"Tennessee","tx":"Texas","ut":"Utah","vt":"Vermont","va":"Virginia","wa":"Washington","wv":"West Virginia","wi":"Wisconsin","wy":"Wyoming"}
TZ = {"wa":"America/Los_Angeles","or":"America/Los_Angeles","ca":"America/Los_Angeles","nv":"America/Los_Angeles","az":"America/Phoenix","ut":"America/Denver","co":"America/Denver","nm":"America/Denver","id":"America/Boise","mt":"America/Denver","wy":"America/Denver",
      "tx":"America/Chicago","ok":"America/Chicago","ks":"America/Chicago","ne":"America/Chicago","sd":"America/Chicago","nd":"America/Chicago","mn":"America/Chicago","ia":"America/Chicago","mo":"America/Chicago","ar":"America/Chicago","la":"America/Chicago","ms":"America/Chicago","al":"America/Chicago","tn":"America/Chicago","wi":"America/Chicago","il":"America/Chicago",
      "hi":"Pacific/Honolulu","ak":"America/Anchorage"}
HERE = os.path.dirname(os.path.abspath(__file__))

def run(*a):
    r = subprocess.run(a, cwd=HERE, capture_output=True, text=True)
    if r.returncode: sys.exit(f"FAILED {' '.join(a)}\n{r.stdout}\n{r.stderr}")
    return r.stdout

def main(city_slug, city_name, cards, city_html):
    st = city_slug.rsplit("-", 1)[1]
    work = os.path.join(HERE, "work", city_slug); evd = os.path.join(work, "ev"); shutil.rmtree(evd, ignore_errors=True); os.makedirs(evd)
    live = os.environ.get("RTT_LIVE_JSON", "/home/claude/stridematt/sitemaps/tools/truth/live.json")
    existing = os.path.join(work, "existing.txt")
    open(existing, "w").write("\n".join(k.split("/")[-1] for k in json.load(open(live))["pages"]))
    towns = sorted({c["town"] for c in json.load(open(cards))} | {city_name})
    run("python3", "city2/conv.py", "--cards", cards, "--city_slug", city_slug, "--city_name", city_name, "--label", city_name,
        "--label_towns", city_name, "--state_code", st.upper(), "--state_name", STATES[st], "--tz", TZ.get(st, "America/New_York"),
        "--out", evd, "--existing", existing)
    run("python3", "enrich_listed.py", evd, city_html)
    for f in glob.glob(evd + "/*.json"):   # facts came from a ticket page, not the host's own site: say so
        s = open(f).read(); e = json.loads(s); org = e["survey"].get("organizer_name") or ""
        host = (e["survey"].get("ticket_link") or "").split("/")[2] if "//" in (e["survey"].get("ticket_link") or "") else ""
        if re.search(r"eventbrite|ticketleap|ticketmaster|universe\.com|showclix|etix", host):
            for p in {org + "'s", org + "’s", org + "'", org + "’"}:
                s = s.replace(p + " own website", "the event's " + host.replace("www.", "").split(".")[0].capitalize() + " page")
        open(f, "w").write(s)
    for f in glob.glob(evd + "/*.json"):
        shutil.copy(f, os.path.join(HERE, "ev"))
        run("python3", "build_listed.py", f)
    bundle = os.path.join(work, f"b_{city_slug}.json.gz")
    print(run("python3", "mkbundle_us.py", bundle, "winterfest-seattle-wa", f"{city_slug}:{cards}").strip())
    bad = 0
    for f in sorted(glob.glob(evd + "/*.json")):
        s = json.load(open(f))["slug"]; b = open(os.path.join(HERE, "out", s, "page.html")).read()
        t = html.unescape(re.sub(r"<[^>]+>", " ", re.sub(r"<script.*?</script>|<style.*?</style>", "", b, flags=re.S)))
        issues = [x for x in ["—", "–", "own website", " None", "null", "undefined", "TODO"] if x in t]
        bad += bool(issues); print(f"{len(t.split()):5d} words  {s}  {issues or ''}")
    print("BUNDLE", bundle, "OK" if not bad else f"{bad} pages need a look")

def city_html(city_slug):
    """The city page's code block, free from the admin domain (no Firecrawl)."""
    import urllib.request
    p = os.path.join(HERE, "work", city_slug); os.makedirs(p, exist_ok=True); f = os.path.join(p, city_slug + ".html")
    if not os.path.exists(f):
        j = json.load(urllib.request.urlopen(f"https://rally-takes-the-train-site.squarespace.com/christmas-events/{city_slug}?format=json", timeout=60))
        open(f, "w").write(j["item"]["body"])
    return f

def multi(cards_file):
    """Cards carrying "page" (city slug) and "page_name": one bundle per city page, one combined bundle for publishing."""
    import gzip
    cards = json.load(open(cards_file)); groups = {}
    for c in cards: groups.setdefault((c["page"], c["page_name"]), []).append(c)
    specs = []
    for (slug_, name), cs in groups.items():
        f = os.path.join(HERE, "work", slug_, "cards.json"); os.makedirs(os.path.dirname(f), exist_ok=True)
        json.dump(cs, open(f, "w"), indent=1, ensure_ascii=False)
        main(slug_, name, f, city_html(slug_)); specs.append(f"{slug_}:{f}")
    out = os.path.join(os.path.dirname(os.path.abspath(cards_file)), "bundle.json.gz")
    print(run("python3", "mkbundle_us.py", out, "winterfest-seattle-wa", *specs).strip())

if __name__ == "__main__":
    if sys.argv[1] == "multi": multi(sys.argv[2])
    else: main(*sys.argv[1:5])
