"""Country rules for verified event pages (one builder for every country).

The event JSON sets survey.country_code (ISO 3166 alpha-2, default "US"). Everything that differs by
country comes from here: date order, spelling of a few house words, currency symbol, page language tag
and the Amazon store for the book card. US output is unchanged (byte for byte) when country_code is US
or missing.

Pages are written in English for every country (the event copy in the JSON is written by hand in the
right variety of English). Translated verified pages are not supported yet.
"""
MONTHS = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"]

# country -> (lang tag, day-first dates, British spelling, Amazon host)
COUNTRIES = {
    "US": ("en-US", False, False, "amazon.com"),
    "CA": ("en-CA", False, False, "amazon.ca"),
    "PH": ("en-PH", False, False, "amazon.com"),
    "GB": ("en-GB", True, True, "amazon.co.uk"),
    "IE": ("en-IE", True, True, "amazon.co.uk"),
    "AU": ("en-AU", True, True, "amazon.com.au"),
    "NZ": ("en-NZ", True, True, "amazon.com.au"),
    "SG": ("en-SG", True, True, "amazon.com"),
    "HK": ("en-HK", True, True, "amazon.com"),
    "IN": ("en-IN", True, True, "amazon.in"),
    "ZA": ("en-ZA", True, True, "amazon.com"),
    "MX": ("en", True, False, "amazon.com.mx"),
    "FR": ("en", True, True, "amazon.fr"), "BE": ("en", True, True, "amazon.fr"), "LU": ("en", True, True, "amazon.fr"),
    "DE": ("en", True, True, "amazon.de"), "AT": ("en", True, True, "amazon.de"), "CH": ("en", True, True, "amazon.de"),
    "NL": ("en", True, True, "amazon.nl"), "IT": ("en", True, True, "amazon.it"), "ES": ("en", True, True, "amazon.es"),
}
DEFAULT = ("en", True, True, "amazon.com")  # any other country: day-first dates, British spelling

SYMBOLS = {"USD": "$", "CAD": "$", "AUD": "$", "NZD": "$", "SGD": "$", "HKD": "$", "MXN": "$", "GBP": "£", "EUR": "€", "JPY": "¥", "INR": "₹", "PHP": "₱"}

US_TO_UK = {"organizer": "organiser", "Organizer": "Organiser", "organizers": "organisers", "Organize": "Organise",
            "coloring": "colouring", "watercolor": "watercolour", "cozy": "cosy", "honor": "honour"}


class Loc:
    def __init__(self, ev):
        s = ev.get("survey", {})
        self.cc = (s.get("country_code") or "US").upper()
        self.lang, self.dmy, self.uk, self.amazon = COUNTRIES.get(self.cc, DEFAULT)
        self.us = self.cc == "US"
        self.currency = s.get("currency") or "USD"

    def date(self, d):
        """datetime.date -> 'November 20, 2026' (US style) or '20 November 2026' (day first)."""
        return f"{d.day} {MONTHS[d.month-1]} {d.year}" if self.dmy else f"{MONTHS[d.month-1]} {d.day}, {d.year}"

    def w(self, word):
        """House words in the page template: organizer, Organize, coloring..."""
        return US_TO_UK.get(word, word) if self.uk else word


def price_re():
    """Price cells that become schema Offers: a currency symbol then a number, e.g. $16, £23.50, €8."""
    return r"^[$£€¥₹₱][0-9.,]+( |$)"
