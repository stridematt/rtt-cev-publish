#!/usr/bin/env python3
"""Discovery candidates -> city-page cards (parse.py shape) with the boilerplate done by code.

Claude writes only a short facts file per city (facts read from each event's own page) plus 2 paragraphs and a tip;
this script derives everything else: card id, When text, badge, calendar rows, filters, tags, host and ticket links.

Usage:
  python3 disc_build.py <facts.json> <city-slug> <out-cards.json>
facts.json: list of
  {"cand": 24, "url": "...", "name": "...", "town": "Raleigh", "venue": "...", "address": "street, town, ST zip",
   "times": [["2026-12-04","17:00","21:00"], ...], "cost": "Free" | "Kids $8; adults $7", "ages": "All ages",
   "host": "...", "kind": "santa|market|lights|show|parade|crafts|story|food|outing|service" (space separated, optional),
   "indoor": true|false|null, "paras": ["...", "..."], "tip": "...", "when_note": "optional text added after the times"}
"""
import json, sys, re, datetime, unicodedata

CHK = "On the host’s page, checked {d}"
MON = ["January","February","March","April","May","June","July","August","September","October","November","December"]
DAY = ["Monday","Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday"]
KIND_TAG = [("service", "Christmas Eve service"), ("santa", "Santa visit"), ("market", "Christmas market"), ("lights", "Christmas lights"),
            ("parade", "Christmas parade"), ("show", "Holiday show"), ("story", "Storytime"), ("crafts", "Christmas crafts"), ("food", "Breakfast with Santa")]
GUESS = [("service", r"christmas eve|candlelight|worship|mass\b|service"), ("santa", r"santa|claus|st\.? nicholas"), ("market", r"market|bazaar|vendor"),
         ("lights", r"light|lighting|glow"), ("parade", r"parade"), ("show", r"nutcracker|carol\b|ballet|concert|cantata|choir|play|theat|symphony|pops|movie|film|screening|wrestling"),
         ("story", r"story ?time|storytime|story"), ("crafts", r"craft|workshop|make and take|cookie decorat"), ("food", r"breakfast|brunch|pancake|cocoa|cookies")]

def slug(s):
    s = unicodedata.normalize("NFKD", s).encode("ascii", "ignore").decode().lower().replace("'", "").replace("&", "and")
    return re.sub(r"-+", "-", re.sub(r"[^a-z0-9]+", "-", s)).strip("-")

def t12(t):
    h, m = map(int, t.split(":")); ap = "am" if h < 12 else "pm"; h = h % 12 or 12
    return ("noon" if (h == 12 and m == 0 and ap == "pm") else f"{h}{'' if not m else ':%02d' % m} {ap}")

def trange(a, b):
    if a and b:
        A, B = t12(a), t12(b)
        if A.endswith(B[-2:]) and A[-2:] in ("am", "pm") and B[-2:] in ("am", "pm"): A = A[:-3]
        return f"{A} to {B}"
    return t12(a) if a else ""

def dlong(iso):
    d = datetime.date.fromisoformat(iso); return f"{DAY[d.weekday()]}, {MON[d.month-1]} {d.day}, {d.year}"

def when_text(times, note=""):
    by = {}
    for d, a, b in times: by.setdefault(d, []).append((a, b))
    days = sorted(by)
    if len(days) == 1:
        slots = by[days[0]]
        s = dlong(days[0]) + ", " + (trange(*slots[0]) if len(slots) == 1 else " and ".join(t12(a) for a, _ in slots))
    elif len(days) <= 4:
        s = "; ".join(dlong(d) + ", " + ", ".join(trange(a, b) for a, b in by[d]) for d in days)
    else:
        s = f"{dlong(days[0])} to {dlong(days[-1])} ({len(days)} dates)"
    return s + (f" ({note})" if note else "")

def badge(times):
    days = sorted({d for d, _, _ in times}); d0 = datetime.date.fromisoformat(days[0])
    if len(days) == 1: return [MON[d0.month-1][:3], str(d0.day), DAY[d0.weekday()][:3]]
    d1 = datetime.date.fromisoformat(days[-1]); return [MON[d0.month-1][:3], str(d0.day), f"to {MON[d1.month-1][:3]} {d1.day}"]

def rbadge(a, b):
    x, y = datetime.date.fromisoformat(a), datetime.date.fromisoformat(b)
    return [MON[x.month-1][:3], str(x.day), f"to {MON[y.month-1][:3]} {y.day}"]

def rwhen(a, b, o, c, note=""):
    s = f"{dlong(a)} to {dlong(b)}" + (", " + trange(o, c) if o else "")
    return s + (f" ({note})" if note else "")

def kinds(f):
    if f.get("kind"): return f["kind"].split()
    hay = (f["name"] + " " + " ".join(f.get("paras", []))).lower()
    name = f["name"].lower()
    first = [k for k, rx in GUESS if re.search(rx, name)]
    rest = [k for k, rx in GUESS if re.search(rx, hay) and k not in first]
    return (first + rest)[:3] or ["outing"]

def card(f, city_key, checked):
    rng = f.get("range")  # [start, end, open, close]: one run of dates (daily or select days)
    if rng:
        r0, r1, ra, rb = (list(rng) + ["", ""])[:4]
        assert re.match(r"2026-1[0-2]-\d\d", r0) and re.match(r"2026-1[12]-\d\d|2027-01-\d\d", r1) and r1 >= "2026-11-25", f"out of season {f['name']}"
        times = [[r0, ra, rb]]
    else:
        times = [[d, a or "", b or ""] for d, a, b in f["times"]]
        for d, a, _ in times: assert re.match(r"2026-1[12]-\d\d|2027-01-0[1-6]", d), f"out of season {f['name']} {d}"
    k = kinds(f); free = f["cost"].lower().startswith("free")
    weekend = any(datetime.date.fromisoformat(d).weekday() >= 5 for d, _, _ in times)
    fl = " ".join(x for x in ["free" if free else "", "weekend" if weekend else "", "indoor" if f.get("indoor") else "",
                              "little" if re.search(r"toddler|ages? [0-3]\b|2 to|little", f.get("ages", ""), re.I) else ""] if x)
    tags = [next((t for kk, t in KIND_TAG if kk == k[0]), "Christmas event")] + (["Free"] if free else [])
    nm = f["name"]; town = f["town"]
    # url = the host's own site (website and Host link); tickets = the ticket seller (tickets button only). Never Eventbrite as the website.
    site = f.get("url") or ""
    if re.search(r"eventbrite\.|ticketleap|ticketmaster", site): site = ""
    if not site: print(f"NOTE no host website for {nm}: tickets link only, no Host link")
    book = f.get("tickets") or site
    for x in (f["paras"] + [f["tip"]]): assert "—" not in x and "–" not in x and "!" not in x, f"dash or ! in {nm}"
    return {"id": f"ev-{city_key}-{slug(nm)}"[:90], "ty": " ".join(k), "fl": fl, "town": town,
            "cal": {"n": nm, "l": f["address"], "u": site, "m": "", "d": ([[r0, ra, rb, r1]] if rng else [[d, a, b, ""] for d, a, b in times])},
            "badge": (rbadge(r0, r1) if rng else badge(times)), "tags": tags, "name": nm,
            "facts": {"When": (rwhen(r0, r1, ra, rb, f.get("when_note", "")) if rng else when_text(times, f.get("when_note", ""))), "Where": f"{f['venue']}, {f['address']}" if f.get("venue") and f["venue"] not in f["address"] else f["address"],
                      "Cost": f["cost"], "Ages": f.get("ages") or "Families"},
            "paras": f["paras"], "tip": f["tip"],
            "dl": {"Host": {"t": f["host"], "href": site}, "Address": {"t": f["address"], "href": ""}, "Confirmed": {"t": CHK.format(d=checked), "href": ""}},
            "book": book, "book_label": [("Get tickets" if f.get("tickets") else "See details and dates"), "from " + re.sub(r"^www\.", "", book.split("/")[2]).split(".")[0].capitalize()],
            "other_tags": [], "verified": False, "cand": f.get("cand"), "page": f.get("page"), "page_name": f.get("page_name")}

if __name__ == "__main__":
    facts, city_slug, out = sys.argv[1], sys.argv[2], sys.argv[3]
    today = datetime.date.today(); checked = f"{MON[today.month-1]} {today.day}, {today.year}"
    cards = [card(f, (f.get("page") or city_slug).rsplit("-", 1)[0], checked) for f in json.load(open(facts))]
    ids = [c["id"] for c in cards]; assert len(ids) == len(set(ids)), "duplicate card ids"
    json.dump(cards, open(out, "w"), indent=1, ensure_ascii=False)
    for c in cards: print(c["id"], "|", c["facts"]["When"], "|", c["ty"], "|", c["fl"])
