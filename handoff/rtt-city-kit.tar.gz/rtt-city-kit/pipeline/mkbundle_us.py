#!/usr/bin/env python3
"""Pack built US event pages + their city-page cards into one bundle for rtt_us_lib.js.
Usage: python3 mkbundle_us.py <out.json.gz> <template-event-slug> <city-slug>:<cards.json> [<city-slug>:<cards.json> ...]
  cards.json = list of parse.py-shape cards (what new_cards.py writes as NEW), each with "id" like ev-seattle-xxx.
  Event pages are read from out/<slug>/page.html and ev/<slug>.json (slug = card's event page slug, matched by source_card).
"""
import json, gzip, hashlib, sys, glob

STATES = {"AL":"Alabama","AK":"Alaska","AZ":"Arizona","AR":"Arkansas","CA":"California","CO":"Colorado","CT":"Connecticut","DE":"Delaware","DC":"District of Columbia","FL":"Florida","GA":"Georgia","HI":"Hawaii","ID":"Idaho","IL":"Illinois","IN":"Indiana","IA":"Iowa","KS":"Kansas","KY":"Kentucky","LA":"Louisiana","ME":"Maine","MD":"Maryland","MA":"Massachusetts","MI":"Michigan","MN":"Minnesota","MS":"Mississippi","MO":"Missouri","MT":"Montana","NE":"Nebraska","NV":"Nevada","NH":"New Hampshire","NJ":"New Jersey","NM":"New Mexico","NY":"New York","NC":"North Carolina","ND":"North Dakota","OH":"Ohio","OK":"Oklahoma","OR":"Oregon","PA":"Pennsylvania","RI":"Rhode Island","SC":"South Carolina","SD":"South Dakota","TN":"Tennessee","TX":"Texas","UT":"Utah","VT":"Vermont","VA":"Virginia","WA":"Washington","WV":"West Virginia","WI":"Wisconsin","WY":"Wyoming"}

def main(out, template, specs):
    evs = {}
    for f in glob.glob("ev/*.json"):
        e = json.load(open(f)); evs[e.get("source_card")] = e
    B = {"v": 1, "template": template, "meta": {}, "pages": {}, "cities": {}}
    for spec in specs:
        city, cf = spec.split(":", 1)
        cards = json.load(open(cf)); B["cities"][city] = []
        for c in cards:
            e = evs.get(c["id"])
            if not e: sys.exit(f"no built event page for card {c['id']}")
            s, p, sv = e["slug"], e["page"], e["survey"]
            h = open(f"out/{s}/page.html").read()
            assert "–" not in h and "—" not in h, s
            primary = next(x for x in p["cities"] if x.get("primary"))
            B["pages"][s + ".html"] = h
            B["meta"][s] = {"title": p["h1"], "seo_title": p["title"], "seo_desc": p["description"], "excerpt": p["description"],
                            "sha": hashlib.sha256(h.encode()).hexdigest()[:16], "town": sv["venue_city"], "state": sv["venue_state"],
                            "state_name": STATES.get(sv["venue_state"], sv["venue_state"]), "city": primary["name"],
                            "tags": ["Christmas events", STATES.get(sv["venue_state"], sv["venue_state"]), primary["name"]]}
            c = dict(c); c["checked"] = e["checked"]
            B["cities"][city].append({"slug": s, "card": c})
    raw = json.dumps(B, ensure_ascii=False).encode()
    open(out, "wb").write(gzip.compress(raw, 9))
    print(out, len(raw), "bytes,", len(B["meta"]), "pages,", {k: len(v) for k, v in B["cities"].items()})

if __name__ == "__main__":
    main(sys.argv[1], sys.argv[2], sys.argv[3:])
