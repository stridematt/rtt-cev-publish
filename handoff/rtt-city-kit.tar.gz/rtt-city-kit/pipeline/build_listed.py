#!/usr/bin/env python3
"""Build a LISTED (not yet verified) event page (Squarespace code block) from one event JSON file.

Usage: python3 build_event.py events/<slug>.json
Writes out/<slug>/: page.html (the post's code block), card.html (event card for each
city page), meta.json (post settings) and preview.html (mock site frame, review only).
The listing card follows the official verified listing format shown on
/verify-your-christmas-event, with Rally's wreath seal.
"""
import json, sys, os, html, re, datetime
from urllib.parse import quote, urlencode
from zoneinfo import ZoneInfo
from tracker import add_utm, org_host, TRACKER_JS

SITE = "https://www.rallytakesthetrain.com"
IMG = "https://res.cloudinary.com/hxoymedx/image/upload/c_fill,ar_1:1,g_auto,w_1000/f_auto,q_auto/v1791955374/Rally_Takes_The_Christmas_Train.png"
def img_ratio(ar, w):  # same source art in the three aspect ratios Google recommends for Event images
    return IMG.replace("c_fill,ar_1:1,g_auto,w_1000", f"c_fill,ar_{ar},g_auto,w_{w}")
IMG_16x9, IMG_4x3, IMG_1x1 = img_ratio("16:9", 1600), img_ratio("4:3", 1200), IMG
IMG_SET = [IMG_16x9, IMG_4x3, IMG_1x1]
WREATH = "https://images.squarespace-cdn.com/content/6219161966192064132104f7/54ecfe13-584a-4a3d-bbeb-8bad727ce1a8/Rally+Takes+The+Train+Christmas.png"
E = lambda s: html.escape(str(s), quote=True)
MONTHS = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"]
DAYS = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]


def nodash(s):
    m = re.search("[\u2013\u2014]", s)
    if m:
        raise SystemExit("em or en dash found near: " + s[max(0, m.start()-60):m.start()+20])
    return s


def tzoff(d, t, tz):
    o = datetime.datetime.fromisoformat(f"{d}T{t}").replace(tzinfo=ZoneInfo(tz)).strftime("%z")
    return o[:3] + ":" + o[3:]


def maps(q):
    return "https://www.google.com/maps/search/?api=1&query=" + quote(q)


def nice_date(iso):
    d = datetime.date.fromisoformat(iso)
    return f"{MONTHS[d.month-1]} {d.day}, {d.year}"


def seal(sfx, cls="rvx-seal"):
    """Rally's Verified wreath, same artwork as the verify page and the badge page."""
    return (f'<svg class="{cls}" viewBox="-16 0 232 240" role="img" aria-label="Verified badge: Rally the corgi in a Christmas wreath with a ribbon that says Verified">'
            f'<defs><linearGradient id="vg{sfx}" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#f9e08a"/><stop offset=".5" stop-color="#dba82f"/><stop offset="1" stop-color="#f6d56b"/></linearGradient>'
            f'<linearGradient id="vr{sfx}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#3b8261"/><stop offset="1" stop-color="#24553f"/></linearGradient>'
            f'<clipPath id="vc{sfx}"><circle cx="100" cy="100" r="87"/></clipPath><path id="vp{sfx}" d="M22 211.5Q100 231.5 178 211.5"/></defs>'
            f'<circle cx="100" cy="100" r="98" fill="url(#vg{sfx})"/><circle cx="100" cy="100" r="93.5" fill="#fffdf8"/>'
            f'<image href="{WREATH}?format=500w" x="13" y="13" width="174" height="174" clip-path="url(#vc{sfx})" preserveAspectRatio="xMidYMid slice"/>'
            f'<circle cx="100" cy="100" r="90" fill="none" stroke="#dba82f" stroke-width="1.2" stroke-dasharray=".1 4.2" stroke-linecap="round"/>'
            f'<path d="M16 188-14 183-4 204l-10 22 34 2Z" fill="#1d4433"/><path d="M184 188l30-5-10 21 10 22-34 2Z" fill="#1d4433"/>'
            f'<path d="M4 182Q100 204 196 182V220Q100 242 4 220Z" fill="url(#vr{sfx})"/>'
            f'<path d="M4 185.5Q100 207.5 196 185.5M4 216.5Q100 238.5 196 216.5" fill="none" stroke="#f6d56b" stroke-width="1" opacity=".8"/>'
            f'<path d="M13 197.5l1.6 4.4 4.4 1.6-4.4 1.6-1.6 4.4-1.6-4.4-4.4-1.6 4.4-1.6Z" fill="#f9e08a"/><path d="M187 197.5l1.6 4.4 4.4 1.6-4.4 1.6-1.6 4.4-1.6-4.4-4.4-1.6 4.4-1.6Z" fill="#f9e08a"/>'
            f'<text font-family="Nunito,system-ui,sans-serif" font-weight="800" font-size="23" letter-spacing="3.5" fill="#fff" text-anchor="middle"><textPath href="#vp{sfx}" startOffset="50%">VERIFIED</textPath></text></svg>')


ICO = {
    "when": '<rect x="3" y="5" width="18" height="16" rx="3"/><path d="M3 10h18M8 3v4M16 3v4"/>',
    "where": '<path d="M12 21s7-6.2 7-11a7 7 0 1 0-14 0c0 4.8 7 11 7 11Z"/><circle cx="12" cy="10" r="2.5"/>',
    "cost": '<path d="M3 9a2 2 0 0 0 0 6v3h18v-3a2 2 0 0 1 0-6V6H3Z"/><path d="M14 6v12"/>',
    "ages": '<circle cx="12" cy="8" r="3.5"/><path d="M5 21c.8-4 3.5-6 7-6s6.2 2 7 6"/>',
    "arrow": '<path d="M5 12h14M13 6l6 6-6 6"/>',
    "check": '<path d="M4 12.5l5 5L20 6.5"/>',
    "star": '<path d="M12 3l2.7 5.6 6.1.9-4.4 4.3 1 6.1L12 17l-5.4 2.9 1-6.1L3.2 9.5l6.1-.9Z"/>',
}


def ico(n):
    return f'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">{ICO[n]}</svg>'


CSS = r"""
.blog-item-top-wrapper,.blog-item-title,.blog-item-meta-wrapper,.blog-meta-section{display:none!important}html body:has(#rvx) .item-pagination{display:none!important}html body:has(#rvx) .blog-item-top-wrapper,html body:has(#rvx) .blog-item-title,html body:has(#rvx) .blog-item-meta-wrapper{display:none!important}
.rvx{--ink:#2b2622;--muted:#5f5650;--coral:#ee7b6c;--coral-d:#e0665b;--red:#a83d33;--cream:#fbf5ea;--paper:#fffdf8;--sand:#f6ecd9;--line:rgba(43,38,34,.1);--night:#172235;--night2:#2a3f66;--gold:#f2c14e;--pine:#24553f;
box-sizing:border-box;max-width:880px;margin:0 auto;font-family:"Nunito",-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;font-size:18px;line-height:1.65;color:var(--ink)}
.rvx *,.rvx *::before,.rvx *::after{box-sizing:border-box}
.rvx.rvx h1,.rvx.rvx h2,.rvx.rvx h3{font-family:"Fraunces",Georgia,serif!important;font-weight:600!important;letter-spacing:-.01em;color:var(--ink)!important;line-height:1.15;scroll-margin-top:96px}
.rvx.rvx h2{margin:0 0 12px;font-size:clamp(25px,3.4vw,32px)}
.rvx.rvx p,.rvx.rvx li,.rvx.rvx dd,.rvx.rvx dt,.rvx.rvx td,.rvx.rvx th{font-family:"Nunito",sans-serif!important;color:var(--ink)}
.rvx p{margin:0 0 14px}
.rvx a{color:var(--red);font-weight:700;text-decoration:underline;text-underline-offset:3px}
.rvx a:focus-visible,.rvx button:focus-visible,.rvx summary:focus-visible{outline:3px solid var(--gold);outline-offset:3px;border-radius:8px}
.rvx .sr{position:absolute!important;width:1px;height:1px;overflow:hidden;clip:rect(0 0 0 0);white-space:nowrap}
.rvx-sec{margin:48px 0}.rvx-sec>h2::before{content:"\2726";display:block;color:var(--gold);font-size:15px;line-height:1;margin-bottom:8px}
/* hero: same night sky as the verify page */
.rvx-hero{--xn-scene:clamp(140px,17.6vw,190px);position:relative;overflow:hidden;border-radius:26px;padding:26px 28px calc(var(--xn-scene) + 10px);color:#fff;isolation:isolate;box-shadow:0 30px 60px -44px rgba(23,34,53,.75);
background:radial-gradient(1.5px 1.5px at 8% 14%,#fff 50%,transparent 52%),radial-gradient(1px 1px at 22% 42%,#fff 50%,transparent 52%),radial-gradient(1.5px 1.5px at 37% 9%,#fff 50%,transparent 52%),radial-gradient(1px 1px at 51% 30%,#fff 50%,transparent 52%),radial-gradient(1.5px 1.5px at 66% 16%,#fff 50%,transparent 52%),radial-gradient(1px 1px at 91% 11%,#fff 50%,transparent 52%),linear-gradient(180deg,#0b1328 0%,var(--night) 46%,#2c4368 100%)}
.rvx-hero canvas{position:absolute;inset:0;width:100%;height:100%;z-index:-1;pointer-events:none}
.rvx.rvx .rvx-crumb{display:flex;flex-wrap:wrap;gap:4px 8px;margin:0 150px 14px 0;padding:0;list-style:none}.rvx.rvx .rvx-crumb li{margin:0;font-size:13px;color:#d9e2f0}
.rvx.rvx .rvx-crumb li+li::before{content:"/";margin-right:8px;opacity:.6}
.rvx .rvx-crumb a{color:#fff;font-weight:600;text-decoration:none}.rvx .rvx-crumb a:hover{text-decoration:underline}
.rvx-snow{position:absolute;top:18px;right:20px;z-index:3;padding:5px 12px;border:1px solid rgba(255,255,255,.3);border-radius:999px;background:rgba(255,255,255,.08);color:#fff;font:700 12px "Nunito",sans-serif;cursor:pointer}
.rvx.rvx .rvx-eyebrow{margin:0 0 8px;font-size:12px;font-weight:800;letter-spacing:.14em;text-transform:uppercase;color:var(--gold)}
.rvx.rvx .rvx-hero h2.rvx-htitle{margin:0 0 12px;max-width:600px;font-size:clamp(32px,5.4vw,50px);color:#fff!important}
.rvx-hero h2.rvx-htitle em{color:var(--gold);font-style:italic;font-weight:500}
.rvx.rvx .rvx-sub{max-width:580px;margin:0 0 16px;font-size:18px;color:#eef2f8}
.rvx-chips{display:flex;flex-wrap:wrap;gap:8px;margin:0 0 20px;padding:0;list-style:none}
.rvx.rvx .rvx-chips li{margin:0;padding:6px 14px;border-radius:999px;background:rgba(255,255,255,.12);border:1px solid rgba(255,255,255,.28);font-size:14px;font-weight:700;color:#fff}
.rvx-chips li::before{content:"\2713";color:var(--gold);margin-right:7px}
.rvx-btn{display:inline-flex;align-items:center;gap:10px;padding:15px 26px;border-radius:999px;background:var(--coral);color:var(--ink)!important;font:700 18px "Nunito",sans-serif;text-decoration:none!important;box-shadow:0 12px 28px -12px rgba(238,123,108,.95);transition:background .15s,transform .15s}
.rvx-btn:hover{background:var(--coral-d);transform:translateY(-1px)}.rvx-btn svg{width:20px;height:20px}
.rvx.rvx .rvx-micro{margin:10px 0 0;font-size:14px;color:#d9e2f0}
.rvx-hero>.rvx-seal{position:absolute;top:58px;right:30px;width:150px;--r:8deg}
.rvx-hero .xn-scene{position:absolute;left:0;right:0;bottom:-1px;z-index:0;display:block;width:100%;height:var(--xn-scene);pointer-events:none}.rvx-hero .xn-scene path[fill="#fbf5ea"]{fill:#fff}.rvx-hero>nav,.rvx-hero>p,.rvx-hero>h2,.rvx-hero>ul,.rvx-hero>a{position:relative;z-index:1}.rvx-hero>.rvx-seal,.rvx-hero>.rvx-snow{z-index:2}.xn-puff{transform-box:fill-box;transform-origin:50% 50%;animation:xn-puff 2.6s ease-out infinite}.xn-puff--2{animation-delay:.5s}.xn-puff--3{animation-delay:1s}.xn-rally{transform-box:fill-box;transform-origin:50% 100%;animation:xn-bob 2.6s ease-in-out infinite}.xn-wheel{transform-box:fill-box;transform-origin:50% 50%;animation:xn-spin 1.3s linear infinite}.rvx-still .xn-puff,.rvx-still .xn-rally,.rvx-still .xn-wheel{animation-play-state:paused!important}@keyframes xn-bob{0%,100%{transform:rotate(-4deg)}50%{transform:rotate(5deg)}}@keyframes xn-spin{100%{transform:rotate(360deg)}}@keyframes xn-puff{0%{transform:translate(4px,5px) scale(.55)}100%{transform:translate(-5px,-6px) scale(1.25);opacity:0}}
/* seal */
.rvx-seal{display:block;height:auto;filter:drop-shadow(0 8px 12px rgba(23,34,53,.28));transform:rotate(var(--r,0deg))}
@keyframes rvx-stamp{0%{opacity:0;transform:rotate(calc(var(--r,0deg) - 14deg)) scale(1.9)}55%{opacity:1;transform:rotate(calc(var(--r,0deg) + 3deg)) scale(.93)}78%{transform:rotate(calc(var(--r,0deg) - 1deg)) scale(1.04)}100%{opacity:1;transform:rotate(var(--r,0deg)) scale(1)}}
.rvx-seal.go{animation:rvx-stamp .75s cubic-bezier(.2,.85,.3,1.15) .35s both}
/* listing: the official verified listing format */
.rvx-list{position:relative;max-width:680px;margin:34px auto 0;padding:24px 22px 18px;background:#fff;border:1px solid var(--line);border-radius:22px;box-shadow:0 24px 48px -40px rgba(43,38,34,.5)}
.rvx-list>.rvx-seal{position:absolute;top:-30px;right:-18px;width:108px;--r:7deg}
.rvx-top{display:flex;gap:14px;align-items:center;padding-right:84px}
.rvx-date{flex:0 0 64px;padding:8px 6px;border-radius:12px;background:#fdebe7;text-align:center;color:var(--red);font-weight:800;font-size:12px;line-height:1.15}
.rvx-date b{display:block;font-family:"Fraunces",Georgia,serif;font-size:30px;font-weight:600;color:var(--ink);line-height:1.05}.rvx-date span{display:block}
.rvx-pills{display:flex;flex-wrap:wrap;align-items:center;gap:6px;margin:0 0 8px}
.rvx-pill{padding:4px 10px;border-radius:999px;background:var(--ink);color:#fff;font-size:11px;font-weight:800;letter-spacing:.08em;text-transform:uppercase}
.rvx-pill.paid{background:#fbe8cf;color:var(--red)}
.rvx-pill.ver{display:inline-flex;align-items:center;gap:6px;padding:2px 10px 2px 3px;background:#fff;color:var(--pine);border:1.5px solid #dba82f}
.rvx-pill.ver img{width:22px;height:22px;border-radius:50%;object-fit:cover;display:block}
.rvx.rvx .rvx-list h2{margin:0;font-size:24px;line-height:1.25}
.rvx-list h2::before{content:none!important}
.rvx .rvx-by{margin:5px 0 0;font-size:14px;color:var(--muted)}
.rvx-facts{display:grid;gap:10px;margin:16px 0 12px;padding:14px;list-style:none;background:#fbf8f2;border-radius:14px}
.rvx-facts li{display:flex;align-items:flex-start;gap:11px;margin:0;font-size:16px;line-height:1.45;font-weight:700}
.rvx-facts svg{flex:0 0 32px;width:32px;height:32px;padding:7px;border-radius:9px;background:#eef5fa;color:var(--red)}
.rvx-facts small{display:block;margin-top:2px;font-size:14px;font-weight:500;color:var(--muted)}
.rvx-about{padding:12px 14px 14px;border-radius:14px;background:var(--cream)}
.rvx .rvx-about__h{margin:0 0 6px;font-size:15px;font-weight:800;color:#7a2f26}.rvx-about__h::before{content:"\2726";color:#c98f12;margin-right:6px}
.rvx .rvx-about p{font-size:16px;margin:0 0 10px}
.rvx .rvx-about p.rvx-tip{padding:10px 12px;border-radius:12px;background:#e6f1e9}
.rvx-grp{margin:0 0 12px}
.rvx .rvx-grp h3{margin:0 0 6px;font:800 12px/1.2 "Nunito",sans-serif!important;letter-spacing:.1em;text-transform:uppercase;color:#7a2f26!important}
.rvx-tags{display:flex;flex-wrap:wrap;gap:6px;margin:0;padding:0;list-style:none}
.rvx-tags li{margin:0;padding:4px 11px;border-radius:999px;background:#fff;border:1px solid rgba(43,38,34,.14);font-size:13.5px;font-weight:600}
.rvx-tbl{display:grid;grid-template-columns:118px 1fr;gap:6px 12px;margin:0;padding:10px 12px;border-radius:12px;background:#fff;font-size:15px}
.rvx-tbl dt{font-weight:800}.rvx-tbl dd{margin:0}
.rvx-cta{display:block;margin-top:12px;padding:11px 20px;border-radius:999px;background:var(--coral);color:var(--ink)!important;text-align:center;text-decoration:none!important;font-size:16px;line-height:1.25}
.rvx-cta small{display:block;font-size:13px;font-weight:600}.rvx-cta:hover{background:var(--coral-d)}
.rvx-calw{position:relative}
.rvx-cal{display:block;width:100%;margin-top:8px;padding:10px 16px;border:1.25px solid #e7c9b5;border-radius:999px;background:#fff;color:var(--ink);font:800 15px "Nunito",sans-serif;cursor:pointer}
.rvx-cal::after{content:"";display:inline-block;width:7px;height:7px;margin-left:8px;border-right:2px solid;border-bottom:2px solid;transform:translateY(-3px) rotate(45deg);opacity:.7}
.rvx-calm{position:absolute;left:0;right:0;top:calc(100% + 6px);z-index:6;display:grid;gap:2px;padding:6px;background:#fff;border:1px solid rgba(43,38,34,.14);border-radius:14px;box-shadow:0 20px 38px -18px rgba(23,34,53,.55)}
.rvx-calm[hidden]{display:none}
.rvx .rvx-calm a{display:block;padding:10px 12px;border-radius:10px;color:var(--ink);font-size:15px;text-decoration:none}.rvx .rvx-calm a:hover{background:var(--cream)}
.rvx-share{display:block;width:100%;margin-top:8px;padding:10px 14px;border:1.5px solid #f0d48a;border-radius:18px;background:linear-gradient(135deg,#fffaf0,#fff3d6);text-align:left;font:700 15px "Nunito",sans-serif;color:var(--ink);cursor:pointer}
.rvx-share small{display:block;font-size:13px;color:#7a4d0c}
/* sections below the listing */
.rvx-weeks{display:grid;grid-template-columns:repeat(3,1fr);gap:10px;margin:0 0 12px}
.rvx-week{padding:14px;border-radius:16px;background:var(--sand)}
.rvx-week b{display:block;font-family:"Fraunces",Georgia,serif;font-size:18px;font-weight:600}
.rvx-week>span{display:block;margin:0 0 10px;font-size:14px;color:var(--muted)}
.rvx-days{display:grid;grid-template-columns:repeat(6,1fr);gap:4px}
.rvx-days i{display:grid;place-items:center;height:30px;border-radius:9px;background:#fff;font:800 12.5px "Nunito",sans-serif;font-style:normal}
.rvx-days i.on{background:var(--night);color:var(--gold)}
.rvx-price{width:100%;margin:0 0 8px;border-collapse:separate;border-spacing:0;overflow:hidden;border:1px solid var(--line);border-radius:16px;background:#fff}
.rvx-price th,.rvx-price td{padding:13px 16px;text-align:left;border-bottom:1px solid var(--line);font-size:17px}
.rvx-price tr:last-child th,.rvx-price tr:last-child td{border-bottom:0}
.rvx-price th{font-weight:600}.rvx.rvx .rvx-price td.long{white-space:normal;text-align:left;font-family:"Nunito",sans-serif!important;font-size:17px;font-weight:700}.rvx-price td{text-align:right;white-space:nowrap;font-family:"Fraunces",Georgia,serif!important;font-size:21px;font-weight:600}
.rvx-locs{display:grid;grid-template-columns:repeat(auto-fit,minmax(250px,1fr));gap:12px;margin:0 0 10px;padding:0;list-style:none}
.rvx-locs li{margin:0;padding:16px 18px;border:1px solid var(--line);border-radius:18px;background:var(--paper);font-size:16px;line-height:1.5}
.rvx-locs b{display:block;margin:0 0 2px;font:800 12px "Nunito",sans-serif;letter-spacing:.12em;text-transform:uppercase;color:var(--red)}
.rvx-locs a{display:inline-block;margin-top:6px;font-size:15px}
.rvx .rvx-note{font-size:14.5px;color:var(--muted)}
.rvx-faq details{padding:4px 0;border-bottom:1px solid var(--line)}
.rvx-quick dl{display:grid;grid-template-columns:repeat(auto-fit,minmax(260px,1fr));gap:10px;margin:0}
.rvx-quick dl>div{background:#fffaf0;border:1px solid #f0dfb4;border-radius:14px;padding:12px 14px}
.rvx-quick dt{font:700 15px/1.35 Nunito,-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;color:var(--ink);margin:0 0 4px}
.rvx-quick dd{margin:0;font-size:15px;line-height:1.5;color:var(--muted)}
.rvx-faq summary{position:relative;padding:14px 34px 14px 0;cursor:pointer;list-style:none;font:600 19px "Fraunces",Georgia,serif;color:var(--ink)}
.rvx-faq summary::-webkit-details-marker{display:none}
.rvx-faq summary::after{content:"+";position:absolute;right:6px;top:10px;font:26px "Fraunces",Georgia,serif;color:var(--red)}
.rvx-faq details[open] summary::after{content:"\2212"}
.rvx .rvx-faq details p{margin:0 0 16px;color:var(--muted)}
.rvx-badge{display:flex;gap:22px;align-items:center;padding:18px 24px;border:1.5px solid #f0d48a;border-radius:20px;background:linear-gradient(135deg,#fffaf0,#fff3d6)}
.rvx-badge .rvx-seal{flex:0 0 120px;width:120px}.rvx-claim__img{flex:0 0 110px;width:110px;height:110px;border-radius:50%;box-shadow:0 0 0 4px #f2c14e}
.rvx.rvx .rvx-badge h2{margin:0 0 6px;font-size:22px}.rvx-badge h2::before{content:none!important}
.rvx .rvx-badge p{margin:0;font-size:16px}
.rvx-more{display:grid;grid-template-columns:repeat(3,1fr);gap:12px;margin:0;padding:0;list-style:none}
.rvx-more li{margin:0}
.rvx-socs{display:flex;flex-wrap:wrap;gap:10px;margin:4px 0 0;padding:0;list-style:none}.rvx.rvx .rvx-socs li{margin:0}.rvx .rvx-soc{display:inline-flex;align-items:center;gap:9px;min-height:48px;padding:0 18px 0 6px;border:1px solid var(--line);border-radius:999px;background:var(--paper);color:var(--ink);font-weight:800;font-size:16px;text-decoration:none}.rvx .rvx-soc svg{width:36px;height:36px;padding:8px;border-radius:50%;background:var(--b);color:#fff;flex:none}.rvx .rvx-soc:hover{border-color:var(--b)}.rvx .rvx-socs--sm{gap:8px;margin-top:8px}.rvx .rvx-socs--sm .rvx-soc{min-height:44px;width:44px;padding:0;justify-content:center;border:0;background:none}.rvx .rvx-socs--sm .rvx-soc span{position:absolute!important;width:1px;height:1px;overflow:hidden;clip:rect(0 0 0 0)}.rvx .rvx-socs--sm .rvx-soc svg{width:34px;height:34px;padding:7px}
.rvx-gks{display:grid;gap:14px}.rvx-gk{padding:18px 20px;background:var(--paper);border:1px solid var(--line);border-radius:18px}.rvx.rvx .rvx-gk h3{margin:0 0 8px;font-size:20px}.rvx.rvx .rvx-gk p{margin:0}.rvx-gk .rvx-note{margin-top:8px!important}.rvx-ticks{display:grid;gap:6px;margin:0;padding:0;list-style:none}.rvx.rvx .rvx-ticks li{display:flex;gap:10px;align-items:flex-start;margin:0;font-size:17px;line-height:1.45}.rvx-ticks svg{width:20px;height:20px;flex:none;margin-top:2px;color:var(--pine)}
.rvx-social{display:flex;flex-wrap:wrap;gap:10px;margin:0;padding:0;list-style:none}.rvx-social li{margin:0}.rvx-social+.rvx-note{margin-top:12px}.rvx .rvx-social a{display:inline-block;padding:10px 16px;border:1px solid var(--line);border-radius:999px;background:var(--paper);color:var(--ink);font-weight:700;text-decoration:none}.rvx .rvx-social a:hover{border-color:var(--red)}
.rvx-gal{display:grid;grid-template-columns:repeat(3,1fr);gap:10px;margin:0;padding:0;list-style:none}.rvx-gal li{margin:0}.rvx-gal img{display:block;width:100%;aspect-ratio:4/3;object-fit:cover;border-radius:14px;background:var(--line)}.rvx-gal li:first-child{grid-column:1/-1}.rvx-gal li:first-child img{aspect-ratio:16/9}
.rvx.rvx .rvx-video{position:relative;aspect-ratio:16/9;border-radius:14px;overflow:hidden;background:#0b1020;margin:0}.rvx .rvx-video iframe{position:absolute;inset:0;width:100%;height:100%;border:0;display:block}
.rtt-gal{display:grid;grid-template-columns:repeat(auto-fill,minmax(200px,1fr));gap:14px;margin:16px 0}.rtt-gal figure{margin:0;min-width:0}.rtt-gal a{display:block;position:relative;border-radius:12px;overflow:hidden;cursor:zoom-in;background:#f3e9d8}.rtt-gal img{width:100%;height:auto;aspect-ratio:1/1;object-fit:cover;display:block;transition:transform .4s ease}.rtt-gal a:hover img{transform:scale(1.04)}.rtt-gal a::after{content:"";position:absolute;right:8px;bottom:8px;width:30px;height:30px;border-radius:50%;background:rgba(43,38,34,.72) url("data:image/svg+xml,%3Csvg xmlns=%27http://www.w3.org/2000/svg%27 viewBox=%270 0 24 24%27 fill=%27none%27 stroke=%27%23fff%27 stroke-width=%272.2%27 stroke-linecap=%27round%27%3E%3Ccircle cx=%2711%27 cy=%2711%27 r=%276%27/%3E%3Cpath d=%27M20 20l-4.5-4.5M11 8v6M8 11h6%27/%3E%3C/svg%3E") center/18px no-repeat;opacity:0;transition:opacity .2s}.rtt-gal a:hover::after,.rtt-gal a:focus-visible::after{opacity:1}.rtt-gal figcaption{font-size:.9rem;margin-top:7px;line-height:1.4;color:var(--ink)}.rtt-gal__d{display:none}.rtt-gal__hint{font-size:.92rem;color:#6b6258;margin:10px 0 0;font-style:italic}.rtt-lb{position:fixed;inset:0;z-index:100000;display:none;align-items:center;justify-content:center;background:rgba(28,24,21,.9);padding:max(16px,env(safe-area-inset-top,0px)) max(16px,env(safe-area-inset-right,0px)) max(16px,env(safe-area-inset-bottom,0px)) max(16px,env(safe-area-inset-left,0px));box-sizing:border-box}.rtt-lb.is-open{display:flex}.rtt-lb__box{background:#fbf5ea;color:#2b2622;border-radius:16px;max-width:1100px;width:100%;max-height:100%;display:flex;flex-direction:column;overflow:hidden;box-shadow:0 20px 60px rgba(0,0,0,.45)}.rtt-lb__fig{margin:0;background:#1f1b18;display:flex;align-items:center;justify-content:center;min-height:min(56vh,440px);flex:1 1 auto;position:relative}.rtt-lb__img{display:block;max-width:100%;max-height:68vh;width:auto;height:auto !important;object-fit:contain}.rtt-lb__txt{padding:16px 20px 18px;overflow-y:auto;flex:0 1 auto}.rtt-lb__k{font-size:.75rem;letter-spacing:.08em;text-transform:uppercase;color:#b8443a;margin:0 0 4px;font-weight:700}.rtt-lb .rtt-lb__t{font-family:"Fraunces",Georgia,serif;font-size:1.3rem;line-height:1.25;margin:0 0 6px;text-wrap:balance;color:#2b2622}.rtt-lb__p{margin:0;line-height:1.55;max-width:68ch;font-size:1rem;color:#2b2622}.rtt-lb__btn{position:absolute;border:0;border-radius:50%;width:44px;height:44px;background:rgba(251,245,234,.94);color:#2b2622;font-size:24px;line-height:44px;text-align:center;cursor:pointer;box-shadow:0 2px 10px rgba(0,0,0,.3);padding:0}.rtt-lb__btn:focus-visible{outline:3px solid #f6b34a;outline-offset:2px}.rtt-lb__x{top:10px;right:10px}.rtt-lb__prev{left:10px;top:50%;transform:translateY(-50%)}.rtt-lb__next{right:10px;top:50%;transform:translateY(-50%)}@media(max-width:600px){.rtt-lb{padding:10px}.rtt-lb__box{border-radius:14px}.rtt-lb__fig{flex:0 0 auto;min-height:220px}.rtt-lb__img{max-height:52vh}.rtt-lb__prev,.rtt-lb__next{top:auto;bottom:8px;transform:none;width:40px;height:40px;line-height:40px}.rtt-lb .rtt-lb__t{font-size:1.15rem}}
.rvx .rvx-more a{display:block;height:100%;padding:16px;border:1px solid var(--line);border-radius:16px;background:var(--paper);color:var(--ink);font-weight:700;text-decoration:none}
.rvx-more a span{display:block;margin-top:4px;font-weight:400;font-size:14.5px;color:var(--muted)}.rvx .rvx-more a:hover{border-color:var(--red)}
.rvx-org{padding:18px 20px;border-radius:18px;background:var(--night);color:#e4eaf3}
.rvx .rvx-org p{margin:0;font-size:16px;color:#e4eaf3}.rvx .rvx-org a{color:var(--gold)}
.rvx-orgf{max-width:680px;margin:28px auto 0;padding:20px 22px;border:1.5px solid #f0d48a;border-radius:20px;background:linear-gradient(135deg,#fffaf0,#fff3d6)}
.rvx.rvx .rvx-orgf h2{margin:0 0 4px;font-size:22px}.rvx .rvx-orgf p{font-size:15.5px;margin:0 0 10px}
.rvx-orgf form{display:grid;gap:10px}.rvx-orgf input[type=email]{padding:13px 14px;border:1.5px solid #e7c9b5;border-radius:12px;font:600 16px "Nunito",sans-serif}
.rvx-orgf__c{display:flex;gap:10px;align-items:flex-start;padding:10px 12px;border:1.5px dashed #e6d6c4;border-radius:12px;background:#fff;font-size:14.5px;line-height:1.45;cursor:pointer}
.rvx-orgf__c input{width:20px;height:20px;margin:1px 0 0;flex:none;accent-color:#ee7b6c}
.rvx-orgf button{justify-self:start;padding:12px 22px;border:0;border-radius:999px;background:var(--coral);color:var(--ink);font:800 16px "Nunito",sans-serif;cursor:pointer}
.rvx .rvx-orgf__err{margin:0;color:#a83d33;font-weight:700;font-size:14px}.rvx .rvx-orgf__fine{margin:0;font-size:13px;color:var(--muted)}
.rvx-orgf.done form{display:none}

.rvg *,.rvg *::before,.rvg *::after{box-sizing:border-box}
.rvg{position:fixed;inset:0;z-index:100000;display:grid;place-items:center;padding:16px;background:rgba(11,19,40,.62);backdrop-filter:blur(3px);-webkit-backdrop-filter:blur(3px);opacity:0;transition:opacity .2s}
.rvg.on{opacity:1}.rvg[hidden]{display:none}
.rvg__c{position:relative;width:min(460px,100%);max-height:calc(100vh - 32px);overflow:auto;scrollbar-width:none;border-radius:26px;background:#fffdf8;box-shadow:0 40px 80px -30px rgba(11,19,40,.8);font-family:"Nunito",-apple-system,sans-serif;color:#2b2622;transform:translateY(14px) scale(.98);transition:transform .25s cubic-bezier(.2,.85,.3,1.15)}
.rvg.on .rvg__c{transform:none}
.rvg__sky{position:relative;height:118px;border-radius:26px 26px 0 0;overflow:hidden;background:radial-gradient(1.4px 1.4px at 10% 22%,#fff 50%,transparent 52%),radial-gradient(1px 1px at 24% 60%,#fff 50%,transparent 52%),radial-gradient(1.6px 1.6px at 41% 18%,#ffe9a8 50%,transparent 52%),radial-gradient(1px 1px at 58% 44%,#fff 50%,transparent 52%),radial-gradient(1.4px 1.4px at 72% 14%,#fff 50%,transparent 52%),radial-gradient(1px 1px at 88% 52%,#fff 50%,transparent 52%),linear-gradient(180deg,#0b1328,#172235 55%,#2c4368)}
.rvg__sky::after{content:"";position:absolute;left:-10%;right:-10%;bottom:-46px;height:80px;border-radius:50%;background:#fffdf8}
.rvg__sky i{position:absolute;width:3px;height:3px;border-radius:50%;background:#fff;opacity:.8;animation:rvg-fall linear infinite}
@keyframes rvg-fall{from{transform:translateY(-10px)}to{transform:translateY(130px)}}
.rvg__seal{position:absolute;left:50%;top:40px;z-index:2;width:104px;margin-left:-52px;filter:drop-shadow(0 10px 14px rgba(23,34,53,.35))}
.rvg__x{position:absolute;top:12px;right:12px;z-index:3;width:36px;height:36px;border:0;border-radius:50%;background:rgba(255,255,255,.14);color:#fff;font:400 24px/1 sans-serif;cursor:pointer}
.rvg__x:hover{background:rgba(255,255,255,.26)}
.rvg__b{padding:46px 26px 22px;text-align:center}
.rvg__k{margin:0 0 6px;font-size:12px;font-weight:800;letter-spacing:.14em;text-transform:uppercase;color:#a83d33}
.rvg__h{margin:0 0 8px;font-family:"Fraunces",Georgia,serif;font-weight:600;font-size:26px;line-height:1.15;color:#2b2622}
.rvg__p{margin:0 0 16px;font-size:16px;line-height:1.5;color:#5f5650}
.rvg form{display:grid;gap:10px;text-align:left}
.rvg label.rvg__l{font-size:13px;font-weight:800;color:#2b2622;margin-bottom:-4px}
.rvg input[type=email],.rvg input[type=text]{width:100%;padding:13px 14px;border:1.5px solid #e7c9b5;border-radius:14px;background:#fff;font:600 16px "Nunito",sans-serif;color:#2b2622}
.rvg input:focus{outline:3px solid rgba(238,123,108,.45);outline-offset:1px;border-color:#ee7b6c}
.rvg__org{display:flex;gap:10px;align-items:flex-start;padding:12px 14px;border:1.5px dashed #e6d6c4;border-radius:14px;background:#fdf8f2;font-size:14px;line-height:1.45;cursor:pointer}
.rvg__org input{width:20px;height:20px;margin:1px 0 0;flex:none;accent-color:#ee7b6c}
.rvg__org:has(input:checked){border-style:solid;border-color:#ee7b6c;background:#fff4f1}
.rvg__go{display:flex;align-items:center;justify-content:center;gap:10px;width:100%;margin-top:4px;padding:15px 18px;border:0;border-radius:999px;background:#ee7b6c;color:#2b2622;font:800 17px "Nunito",sans-serif;cursor:pointer;box-shadow:0 12px 26px -14px rgba(238,123,108,.95);transition:background .15s,transform .15s}
.rvg__go:hover{background:#e0665b;transform:translateY(-1px)}.rvg__go[disabled]{opacity:.7;cursor:default}
.rvg__go svg{width:20px;height:20px}
.rvg__err{min-height:0;margin:0;color:#a83d33;font-size:14px;font-weight:700}
.rvg__fine{margin:6px 0 0;font-size:12.5px;line-height:1.45;color:#7a6f68;text-align:center}.rvg__fine a{color:#a83d33}
.rvg__skip{display:block;margin:12px auto 0;border:0;background:none;color:#5f5650;font:700 14px "Nunito",sans-serif;text-decoration:underline;text-underline-offset:3px;cursor:pointer}
.rvg__ok{display:none}.rvg.done .rvg__ask{display:none}.rvg.done .rvg__ok{display:block}
.rvg__ok a.rvg__go{text-decoration:none}
@media (prefers-reduced-motion:reduce){.rvg,.rvg__c{transition:none}.rvg__sky i{animation:none}}

/* live countdown chip */
.rvx.rvx .rvx-chips li.rvx-live{background:rgba(242,193,78,.18);border-color:rgba(242,193,78,.6);color:#fff}
.rvx.rvx .rvx-chips li.rvx-live::before{content:"";display:inline-block;width:8px;height:8px;margin-right:8px;border-radius:50%;background:#ff6a5c;box-shadow:0 0 0 0 rgba(255,106,92,.7);animation:rvx-pulse 2s ease-out infinite;vertical-align:1px}
@keyframes rvx-pulse{70%,100%{box-shadow:0 0 0 9px rgba(255,106,92,0)}}
/* route map */
.rvx-route{position:relative;margin:0 0 14px;padding:18px 18px 8px;border-radius:22px;overflow:hidden;background:linear-gradient(180deg,#172235,#24365a);color:#fff}
.rvx-route svg{display:block;width:100%;height:auto}
.rvx-route .st{cursor:pointer}.rvx-route .st circle.o{transition:r .2s}.rvx-route .st:hover circle.o,.rvx-route .st:focus circle.o{r:13}
.rvx-route .st:focus{outline:none}.rvx-route .st:focus-visible circle.o{stroke:#f2c14e;stroke-width:3}
.rvx.rvx .rvx-route p{margin:6px 4px 8px;font-size:14px;color:#d9e2f0}
.rvx-locs li.hl{border-color:#ee7b6c;box-shadow:0 0 0 3px rgba(238,123,108,.25)}
/* price calculator */
.rvx-calc{display:grid;grid-template-columns:1fr 1fr auto;gap:12px;align-items:end;margin:0 0 10px;padding:16px 18px;border-radius:18px;background:var(--night);color:#fff}
.rvx-calc label{display:block;font-size:13px;font-weight:800;color:#d9e2f0;margin:0 0 6px}
.rvx-step{display:flex;align-items:center;gap:0;border:1.5px solid rgba(255,255,255,.3);border-radius:999px;overflow:hidden;width:max-content}
.rvx-step button{width:40px;height:40px;border:0;background:rgba(255,255,255,.08);color:#fff;font:800 20px "Nunito",sans-serif;cursor:pointer}
.rvx-step button:hover{background:rgba(255,255,255,.18)}
.rvx-step output{min-width:40px;text-align:center;font:800 18px "Nunito",sans-serif}
.rvx-calc__t{text-align:right}.rvx-calc__t small{display:block;font-size:13px;color:#d9e2f0}
.rvx-calc__t b{display:block;font:600 34px/1 "Fraunces",Georgia,serif;color:var(--gold)}
/* nearby events */
.rvx-near{display:grid;grid-template-columns:repeat(3,1fr);gap:12px;margin:0 0 12px;padding:0;list-style:none}
.rvx-near li{margin:0}
.rvx .rvx-near a{display:flex;flex-direction:column;gap:6px;height:100%;padding:16px;border-radius:18px;border:1px solid var(--line);background:#fff;color:var(--ink);text-decoration:none;box-shadow:0 18px 34px -30px rgba(43,38,34,.6);transition:transform .15s,border-color .15s}
.rvx .rvx-near a:hover{transform:translateY(-2px);border-color:#ee7b6c}
.rvx-near .tg{align-self:flex-start;padding:3px 9px;border-radius:999px;background:#e6f1e9;color:var(--pine);font-size:11px;font-weight:800;letter-spacing:.08em;text-transform:uppercase}
.rvx-near b{font-family:"Fraunces",Georgia,serif;font-size:17px;font-weight:600;line-height:1.25}
.rvx-near span{font-size:14px;color:var(--muted);line-height:1.4}
.rvx-near em{font-style:normal;font-size:13px;font-weight:700;color:var(--red)}
@media (max-width:640px){.rvx-calc{grid-template-columns:1fr 1fr}.rvx-calc__t{grid-column:1/-1;text-align:left}.rvx-near{grid-template-columns:1fr}}
.rvx-dl{list-style:none;margin:0 0 12px;padding:0;display:grid;gap:10px}.rvx-dl li{display:flex;flex-wrap:wrap;gap:4px 14px;align-items:baseline;padding:14px 18px;border:1px solid var(--line);border-radius:16px;background:var(--paper)}.rvx.rvx .rvx-dl b{font-family:"Fraunces",Georgia,serif!important;font-weight:600;font-size:20px}.rvx.rvx .rvx-dl span{color:var(--muted)}
.rvx-toast{position:fixed;left:50%;bottom:24px;z-index:9999;transform:translateX(-50%);padding:12px 18px;border-radius:12px;background:var(--night);color:#fff;font:700 15px "Nunito",sans-serif;opacity:0;transition:opacity .2s}
.rvx-toast.on{opacity:1}
@media (max-width:640px){
.rvx{font-size:17px}.rvx-hero{padding:22px 18px 0;border-radius:20px}.rvx-crumb{margin-right:96px}
.rvx-hero>.rvx-seal{position:static;width:96px;margin:4px 0 10px;--r:-4deg}
.rvx-btn{display:flex;justify-content:center}.rvx-hero{padding-bottom:calc(var(--xn-scene) + 6px)}
.rvx-list{padding:22px 14px 14px}.rvx-date{flex-basis:54px}.rvx-top{gap:10px}.rvx-list>.rvx-seal{width:84px;top:-26px;right:-8px}.rvx-top{padding-right:58px}
.rvx-tbl{grid-template-columns:1fr;gap:2px 0}.rvx-tbl dd{margin-bottom:6px}
.rvx-weeks,.rvx-more{grid-template-columns:1fr}.rvx-gal{grid-template-columns:1fr 1fr}.rvx-badge{flex-direction:column;text-align:center;padding:18px 16px}
}
@media (prefers-reduced-motion:reduce){.rvx *{transition:none!important}.rvx-seal.go,.xn-puff,.xn-rally,.xn-wheel{animation:none}}
.rvx h1,.rvx h2,.rvx h3,.rvx p,.rvx li,.rvx dd,.rvx td{overflow-wrap:anywhere}
/* book gift card (live since Nov 15, 2026) */
.rvx-gift{display:flex;gap:26px;align-items:center;padding:24px 26px;border-radius:22px;background:linear-gradient(135deg,#fff6ec 0%,#ffe9dc 100%);border:1.5px solid #f4c7b4;box-shadow:0 18px 40px -26px rgba(238,123,108,.9);position:relative}
.rvx-gift__k{display:inline-block;margin:0 0 8px;padding:4px 12px;border-radius:999px;background:#c8102e;color:#fff;font:800 12px/1.4 "Nunito",sans-serif;letter-spacing:.06em;text-transform:uppercase}
.rvx-gift__cov{flex:0 0 190px;display:block;border-radius:12px;overflow:hidden;box-shadow:0 14px 30px -14px rgba(0,0,0,.45);transform:rotate(-2deg);transition:transform .2s}
.rvx-gift__cov:hover{transform:rotate(0) scale(1.03)}
.rvx-gift__cov img{display:block;width:100%;height:auto}
.rvx-gift__b{flex:1;min-width:0}
.rvx-gift h2{margin:0 0 8px!important}
.rvx-gift__p{margin:0 0 12px;font-size:17px;line-height:1.5}
.rvx-gift__l{list-style:none;margin:0 0 14px;padding:0}
.rvx-gift__l li{margin:0 0 6px;padding-left:28px;position:relative;font-size:16px;line-height:1.4}
.rvx-gift__l li:before{content:"\2714";position:absolute;left:0;top:0;width:20px;height:20px;border-radius:50%;background:#2e8b57;color:#fff;font-size:12px;line-height:20px;text-align:center}
.rvx-gift__pr{margin:0 0 14px;font:800 22px "Nunito",sans-serif}
.rvx-gift__pr small{font:600 14px "Nunito",sans-serif;opacity:.75;margin-left:6px}
.rvx-gift__btns{display:flex;flex-wrap:wrap;gap:12px}
.rvx-gift__btns a{display:inline-flex;align-items:center;justify-content:center;padding:14px 24px;border-radius:999px;font:800 17px "Nunito",sans-serif;text-decoration:none!important;transition:transform .15s}
.rvx-gift__btns a:hover{transform:translateY(-2px)}
.rvx-gift__s{background:#c8102e;color:#fff!important;box-shadow:0 12px 26px -12px rgba(200,16,46,.95)}
.rvx-gift__a{background:#fff;color:#1d2433!important;border:2px solid #1d2433}
.rvx-gift__st{font-weight:800;color:#c8102e!important;white-space:nowrap}
.rvx-gift__n{margin:10px 0 0;font-size:14px;opacity:.8}
@media(max-width:640px){.rvx-gift{flex-direction:column;text-align:center;padding:22px 18px}.rvx-gift__cov{flex:0 0 auto;width:170px}.rvx-gift__l{display:inline-block;text-align:left}.rvx-gift__btns{justify-content:center}.rvx-gift__btns a{width:100%}}
.rvx-gift--s{gap:22px;padding:20px 22px}
.rvx-gift--s .rvx-gift__cov{flex:0 0 150px}
.rvx.rvx .rvx-gift--s h2{font-size:24px;line-height:1.2;margin:0 0 6px!important}
.rvx-gift--s .rvx-gift__p{font-size:16px;margin:0 0 10px}
.rvx-gift__q{margin:0 0 10px;font-size:15px;line-height:1.45;font-style:italic}
.rvx-gift__q a{font-style:normal;font-weight:700;color:#c8102e!important;white-space:nowrap}
.rvx-gift__stars{color:#f2b01e;font-style:normal;letter-spacing:1px;margin-right:4px}
.rvx-gift__c{list-style:none;display:flex;flex-wrap:wrap;gap:6px;margin:0 0 14px;padding:0}
.rvx-gift__c li{margin:0;padding:4px 10px;border-radius:999px;background:#fff;border:1px solid #f0cdbd;font-size:14px;line-height:1.3}
.rvx-gift--s .rvx-gift__btns a{padding:12px 20px;font-size:16px}
@media(max-width:640px){.rvx-gift--s .rvx-gift__cov{width:130px}.rvx-gift__c{justify-content:center}}
"""

GIFT_HTML = '<section class="rvx-sec" aria-labelledby="h-gift"><div class="rvx-gift rvx-gift--s"><a class="rvx-gift__cov" href="https://www.rallytakesthetrain.com/shop/p/author-signed-copy-rally-takes-the-train" data-out="book-signed-cover"><img src="https://images.squarespace-cdn.com/content/v1/6219161966192064132104f7/50fbc445-6da8-443f-b30f-1f414b1c835b/Rally+Takes+The+Train+Cover+%281200+x+1200+px%29.png?format=500w" alt="Rally Takes the Train picture book cover, a corgi on a train" width="150" height="150" loading="lazy"></a><div class="rvx-gift__b"><span class="rvx-gift__k">Christmas gift pick</span><h2 id="h-gift">A Christmas gift kids will read again and again</h2><p class="rvx-gift__p">Rally the corgi rides a real train to see his grandparents and finds his courage in a dark tunnel. A cozy 5-minute rhyming read-aloud, written in honor of the author\'s mom. <a class="rvx-gift__st" href="https://www.rallytakesthetrain.com/our-story" data-out="book-story">Our story</a></p><p class="rvx-gift__q"><span class="rvx-gift__stars" role="img" aria-label="5 out of 5 stars">&#9733;&#9733;&#9733;&#9733;&#9733;</span> &ldquo;The perfect read-aloud for the dog-loving child.&rdquo; <a href="https://reedsy.com/discovery/book/rally-takes-the-train-kelsey-cecil#review" target="_blank" rel="noopener" data-out="book-review">Reedsy Discovery<span class="sr"> review (opens in a new tab)</span></a></p><ul class="rvx-gift__c"><li>Signed by the author</li><li>Hand-painted watercolor</li><li>Ages 0 to 8</li></ul><div class="rvx-gift__btns"><a class="rvx-gift__s" href="https://www.rallytakesthetrain.com/shop/p/author-signed-copy-rally-takes-the-train" data-out="book-signed">Get a signed copy, $16.99</a><a class="rvx-gift__a" href="https://www.amazon.com/dp/B0BLJG8VKL" target="_blank" rel="noopener" data-out="book-amazon">Buy on Amazon<span class="sr"> (opens in a new tab)</span></a></div></div></div></section>'  # Rally book gift card v3 (simplified, Nov 15, 2026)

BORROW = os.environ.get("BORROW_SCENE")=="1"
LEADS_ENDPOINT = os.environ.get("LEADS_ENDPOINT", "")  # Apps Script web app URL for organizer opt-ins and click counts
LEADS_LIVE = os.environ.get("LEADS_LIVE") == "1" and LEADS_ENDPOINT.startswith("https://script.google.com/")  # only after the privacy policy update is published
_SCENE = open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "assets", "xn_scene.svg")).read()  # Rally on the train, from the site hero (cev/hub_tpl/evhub_blockA.html)

JS = r"""<script>
__TRACKER__
(function(){
var R0=document.getElementById('rvx');if(!R0)return;
function boot(){
var R=R0;var ev=JSON.parse(R.getAttribute('data-ev'));
/* organizer opt-ins and click counts go to Rally's private organizer backend (never to the organizer directly) */
var LG=document.querySelector('.rvx-gated'),LURL=LG?LG.getAttribute('data-ke-leads')||'':'',LT0=Date.now();
function lpost(o){if(!/^https:\/\/script\.google\.com\//.test(LURL))return;var body=JSON.stringify(o);try{if(navigator.sendBeacon&&navigator.sendBeacon(LURL,new Blob([body],{type:'text/plain;charset=utf-8'})))return}catch(x){}try{fetch(LURL,{method:'POST',mode:'no-cors',body:body,keepalive:true,credentials:'omit',referrerPolicy:'no-referrer'})}catch(x){}}
function orgLead(email,city,text,hp){lpost({action:'lead',event:LG.getAttribute('data-ke-event'),email:email,city:city||'',lang:'en',country:LG.getAttribute('data-ke-country')||'US',consent:true,consent_version:'org-optin-v2',consent_text:text,page:location.pathname,ms:Date.now()-LT0,hp:hp||''})}
function orgThanks(){var o=LG.getAttribute('data-ke-org'),n=LG.getAttribute('data-ke-event-name');return LG.getAttribute('data-ke-org-paid')==='1'?'Check your inbox and tap the link to confirm. Then '+o+' can email you about '+n+'.':'Check your inbox and tap the link to confirm. Then we pass your email to '+o+' through their organizer account so they can contact you about '+n+'. If they do not collect it within 120 days, we delete it.'}
/* visits and outbound clicks, counted once per browser per day (see tracker.py) */
if(window.__rttT&&LG){__rttT.add({url:LURL,event:LG.getAttribute('data-ke-event'),host:LG.getAttribute('data-ke-org-host'),src:'event'});__rttT.send(LURL,{event:LG.getAttribute('data-ke-event'),kind:'view',src:'event'})}
function ga(n,p){try{window.gtag&&gtag('event',n,Object.assign({event_slug:ev.slug,page_type:'listed_event'},p||{}))}catch(e){}}
function toast(m){var t=document.createElement('div');t.className='rvx-toast';t.setAttribute('role','status');t.textContent=m;document.body.appendChild(t);requestAnimationFrame(function(){t.classList.add('on')});setTimeout(function(){t.classList.remove('on');setTimeout(function(){t.remove()},300)},2400)}
/* stamp the seals when they come into view */
var seals=R.querySelectorAll('.rvx-seal');if('IntersectionObserver' in window){var io=new IntersectionObserver(function(es){es.forEach(function(e){if(e.isIntersecting){e.target.classList.add('go');io.unobserve(e.target)}})},{threshold:.4});seals.forEach(function(s){io.observe(s)})}else seals.forEach(function(s){s.classList.add('go')});
/* snow and Rally's train (same motion as the site hero) */
var H0=R.querySelector('.rvx-hero'),cv=R.querySelector('canvas'),btn=R.querySelector('.rvx-snow'),run=!window.matchMedia('(prefers-reduced-motion: reduce)').matches,c=cv&&cv.getContext?cv.getContext('2d'):null,f=[],W=0,Hh=0,dpr=Math.min(window.devicePixelRatio||1,2),last=0;
function sz(){if(!c)return;W=cv.offsetWidth;Hh=cv.offsetHeight;cv.width=W*dpr;cv.height=Hh*dpr;c.setTransform(dpr,0,0,dpr,0,0)}sz();
for(var i=0;i<60;i++)f.push({x:Math.random()*1200,y:Math.random()*600,r:Math.random()*1.8+.6,s:Math.random()*14+8,w:Math.random()*6.3});
var train=R.querySelector('.xn-train'),track=R.querySelector('#xn-track'),cars=train?train.querySelectorAll('.xn-car'):[],offs=[],tl=0,sc=1.45,ts=0,tail=0,sMin=0,sMax=0;
try{if(track&&track.getTotalLength){tl=track.getTotalLength();sc=parseFloat(train.getAttribute('data-scale'))||sc;[].forEach.call(cars,function(cc){var o=parseFloat(cc.getAttribute('data-o'))||0;offs.push(o);tail=Math.max(tail,o)});ts=tl*.62}}catch(e){tl=0}
function span(first){if(!tl)return;var b=track.ownerSVGElement.getBoundingClientRect(),k=Math.max(b.width/1080,b.height/190)||1,vw=Math.min(1080,b.width/k),left=540-vw/2,len=function(x){return(x+80)/1240*tl};sMin=Math.max(0,len(left-70));sMax=Math.min(tl,len(left+vw+50))+tail;if(first)ts=len(left+vw*(vw>800?.7:.6))}
function place(){for(var i=0;i<cars.length;i++){var d=Math.max(0,Math.min(tl,ts-offs[i])),p=track.getPointAtLength(d),q=track.getPointAtLength(Math.min(tl,d+3)),an=d>=tl-3?0:Math.atan2(q.y-p.y,q.x-p.x)*57.2958;cars[i].setAttribute('transform','translate('+p.x.toFixed(1)+' '+p.y.toFixed(1)+') rotate('+an.toFixed(1)+') scale('+sc+')')}}
function frame(now){var dt=Math.min(.05,Math.max(0,(now-last)/1000));last=now;
if(c){c.clearRect(0,0,W,Hh);c.fillStyle='rgba(255,255,255,.85)';for(var i=0;i<f.length;i++){var p=f[i];p.y+=p.s*dt;p.w+=.6*dt;if(p.y>Hh){p.y=-4;p.x=Math.random()*W}c.beginPath();c.arc(p.x%Math.max(W,1)+Math.sin(p.w)*6,p.y,p.r,0,6.3);c.fill()}}
if(tl){ts+=26*dt;if(ts>sMax+90)ts=sMin;place()}
if(run)requestAnimationFrame(frame)}
span(run);if(tl)place();
function go(){last=performance.now();requestAnimationFrame(frame)}
if(run)go();else if(c){frame(performance.now())}
H0.classList.toggle('rvx-still',!run);
window.addEventListener('resize',function(){sz();span(false)});
if(btn){btn.textContent=run?'Pause the snow':'Play the snow';btn.addEventListener('click',function(){run=!run;btn.textContent=run?'Pause the snow':'Play the snow';btn.setAttribute('aria-pressed',String(!run));H0.classList.toggle('rvx-still',!run);if(run)go()})}
/* add to calendar menu */
var cb=R.querySelector('.rvx-cal'),cm=R.querySelector('.rvx-calm');
if(cb&&cm){cb.addEventListener('click',function(){var o=cm.hidden;cm.hidden=!o;cb.setAttribute('aria-expanded',String(o))});
document.addEventListener('click',function(e){if(!cm.hidden&&!e.target.closest('.rvx-calw')){cm.hidden=true;cb.setAttribute('aria-expanded','false')}});
cm.querySelectorAll('a').forEach(function(a){a.addEventListener('click',function(e){ga('add_to_calendar',{provider:a.getAttribute('data-p')});if(a.getAttribute('data-p')!=='ics')return;e.preventDefault();
var ics=['BEGIN:VCALENDAR','VERSION:2.0','PRODID:-//Rally Takes the Train//Verified events//EN','BEGIN:VEVENT','UID:'+ev.slug+'@rallytakesthetrain.com','DTSTAMP:'+new Date().toISOString().replace(/[-:]/g,'').slice(0,15)+'Z',(ev.ds?'DTSTART:'+ev.ds:'DTSTART;VALUE=DATE:'+ev.start.replace(/-/g,'')),(ev.de?'DTEND:'+ev.de:'DTEND;VALUE=DATE:'+ev.endx.replace(/-/g,'')),(ev.rr?'RRULE:'+ev.rr:''),'SUMMARY:'+ev.name,'LOCATION:'+ev.where,'DESCRIPTION:'+ev.desc+'\\n'+ev.url,'URL:'+ev.url,'END:VEVENT','END:VCALENDAR'].filter(Boolean).join('\r\n');
var d=document.createElement('a');d.href=URL.createObjectURL(new Blob([ics],{type:'text/calendar'}));d.download=ev.slug+'.ics';document.body.appendChild(d);d.click();setTimeout(function(){URL.revokeObjectURL(d.href);d.remove()},500);cm.hidden=true;toast('Calendar file downloaded')})})}
/* share */
var sh=R.querySelector('.rvx-share');if(sh)sh.addEventListener('click',function(){var d={title:ev.name,text:ev.name+', '+ev.when,url:ev.url};
if(navigator.share)navigator.share(d).catch(function(){});else if(navigator.clipboard)navigator.clipboard.writeText(ev.url).then(function(){toast('Link copied')});ga('share',{method:navigator.share?'native':'copy'})});
var of=R.querySelector('.rvx-orgf form');if(of)of.addEventListener('submit',function(e){e.preventDefault();var em=of.querySelector('input[type=email]'),cb=of.querySelector('input[type=checkbox]'),er=of.querySelector('.rvx-orgf__err'),v=(em.value||'').trim(),G=document.querySelector('.rvx-gated');
if(!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(v)){er.textContent='Please enter a valid email address.';em.focus();return}
if(!cb.checked){er.textContent='Please tick the box so we can pass your email to '+G.getAttribute('data-ke-org')+'.';cb.focus();return}er.textContent='';

orgLead(v,'',cb.parentNode.textContent.replace(/\s+/g,' ').trim(),(of.querySelector('input[name=website]')||{}).value);
var btn=of.querySelector('button');btn.disabled=true;btn.textContent='Sending...';
function done(){of.parentNode.classList.add('done');var p=document.createElement('p');p.setAttribute('role','status');p.textContent='Almost done. '+orgThanks();of.parentNode.appendChild(p);ga('organizer_optin',{})}
setTimeout(done,400)});
/* live countdown */
var lv=R.querySelector('[data-rvx-live]');if(lv){var td=new Date();td.setHours(0,0,0,0);var sd=new Date(ev.start+'T00:00:00'),ed=new Date(ev.endx+'T00:00:00'),dd=Math.round((sd-td)/864e5);
if(td<sd){lv.textContent=dd===1?'Starts tomorrow':'Starts in '+dd+' days';lv.hidden=false}else if(td<ed){var wk=Math.floor((td-sd)/(7*864e5))+1;lv.textContent='Happening now: week '+wk;lv.hidden=false}else{lv.textContent='The '+ev.start.slice(0,4)+' session has ended';lv.hidden=false;lv.classList.remove('rvx-live')}}
/* route map: stops and Rally's train riding the track */
R.querySelectorAll('.rvx-route .st').forEach(function(g){function go(){var ids=(g.getAttribute('data-locs')||'').split(' ').filter(Boolean),first=null;R.querySelectorAll('.rvx-locs li').forEach(function(x){x.classList.remove('hl')});ids.forEach(function(id){var li=document.getElementById(id);if(li){li.classList.add('hl');if(!first)first=li}});if(first)first.scrollIntoView({block:'center',behavior:'smooth'});ga('verified_map_stop',{stop:g.getAttribute('aria-label')})}
g.addEventListener('click',go);g.addEventListener('keydown',function(e){if(e.key==='Enter'||e.key===' '){e.preventDefault();go()}})});
(function(){var rt=R.querySelector('#rvx-rt'),host=R.querySelector('.rvx-rt-train'),src=R.querySelector('.rvx-hero .xn-train');if(!rt||!host||!src||!rt.getTotalLength)return;
var tr=src.cloneNode(true);tr.removeAttribute('class');host.appendChild(tr);var cars=tr.querySelectorAll('.xn-car'),offs=[].map.call(cars,function(c){return (parseFloat(c.getAttribute('data-o'))||0)*.78}),L=rt.getTotalLength(),tail=Math.max.apply(null,offs.concat([0])),s=tail+10,dir=1,last=0,sc=1.12;
function put(){for(var i=0;i<cars.length;i++){var dd=Math.max(0,Math.min(L,s-dir*offs[i]*-1*-1)),d=dir>0?Math.max(0,Math.min(L,s-offs[i])):Math.max(0,Math.min(L,s+offs[i])),p=rt.getPointAtLength(d),q=rt.getPointAtLength(Math.min(L,Math.max(0,d+3*dir))),an=Math.atan2(q.y-p.y,q.x-p.x)*57.2958;cars[i].setAttribute('transform','translate('+p.x.toFixed(1)+' '+p.y.toFixed(1)+') rotate('+an.toFixed(1)+') scale('+(dir>0?sc:sc)+','+(dir>0?sc:-sc)+')')}}
var mv=!window.matchMedia('(prefers-reduced-motion: reduce)').matches,vis=false;
if('IntersectionObserver' in window){new IntersectionObserver(function(es){vis=es[0].isIntersecting;if(vis&&mv){last=performance.now();requestAnimationFrame(f)}}).observe(rt.ownerSVGElement)}
function f(now){var dt=Math.min(.05,(now-last)/1000);last=now;s+=dir*34*dt;if(s>L){s=L;dir=-1}else if(s<0){s=0;dir=1}put();if(vis&&mv&&!R.querySelector('.rvx-hero.rvx-still'))requestAnimationFrame(f)}put()})();
/* price calculator */
var cc=R.querySelector('.rvx-calc');if(cc){var P=JSON.parse(cc.getAttribute('data-calc')),k=1,bb=0,ko=cc.querySelector('[data-k]'),bo=cc.querySelector('[data-b]'),to=cc.querySelector('[data-tot]');
function tot(){var t=0;for(var i=0;i<k;i++)t+=i<P.tiers.length?P.tiers[i]:P.after;ko.textContent=k;bo.textContent=bb;to.textContent='$'+t}
cc.addEventListener('click',function(e){var b=e.target.closest('button');if(!b)return;var d=b.getAttribute('data-d');if(d==='k+')k=Math.min(8,k+1);if(d==='k-')k=Math.max(1,k-1);if(d==='b+')bb=Math.min(4,bb+1);if(d==='b-')bb=Math.max(0,bb-1);tot();ga('verified_price_calc',{kids:k,babies:bb})});tot()}
/* Rally's email gate for verified event pages (same list and hook as the site-wide link gate) */
var GD=document.querySelector('.rvx-gated'),ORG=GD?GD.getAttribute('data-ke-org'):'',SHARE=GD&&(GD.getAttribute('data-ke-org-share')==='1'||(/[?&]rvtest=1(&|$)/.test(location.search)&&/^https:\/\/script\.google\.com\//.test(GD.getAttribute('data-ke-leads')||''))),PAID=GD&&GD.getAttribute('data-ke-org-paid')==='1',LEADS=GD?GD.getAttribute('data-ke-leads')||'':'',T0=Date.now(),ALLOW_SKIP=true,HOOK='https://hooks.zapier.com/hooks/catch/29219243/49kh13v/',KEY='ke-unlocked-v1';
function lsg(k){try{return localStorage.getItem(k)}catch(e){return null}}
function unlocked(){var sk=null;try{sk=sessionStorage.getItem('ke-skip')}catch(e){}return !!lsg(KEY)||!!sk||/(?:^|; )ke-unlocked-v1=/.test(document.cookie)||document.documentElement.getAttribute('data-ke-gate')==='off'}
var gate=null,pend=null,lastF=null;
function host(u){try{return new URL(u).hostname.replace(/^www\./,'')}catch(e){return u}}
function buildGate(){gate=document.createElement('div');gate.className='rvg';gate.hidden=true;gate.setAttribute('data-ke-skip','');
var city=(R.getAttribute('data-city')||'');
gate.innerHTML='<div class="rvg__c" role="dialog" aria-modal="true" aria-labelledby="rvg-h"><div class="rvg__sky" aria-hidden="true"></div><button type="button" class="rvg__x" aria-label="Close">&times;</button>'+(R.querySelector('.rvx-badge .rvx-seal')||{outerHTML:'<img class="rvg__seal" src="'+R.querySelector('.rvx-claim__img').src+'" alt="" style="border-radius:50%">'}).outerHTML.replace('class="rvx-seal','class="rvg__seal').replace(/id="v([grcp])b"/g,'id="v$1g"').replace(/#v([grcp])b\)/g,'#v$1g)').replace(/href="#vpb"/,'href="#vpg"')+
'<div class="rvg__b"><div class="rvg__ask"><p class="rvg__k"></p><h2 class="rvg__h" id="rvg-h"></h2><p class="rvg__p"></p>'+
'<form novalidate><label class="rvg__l" for="rvg-e">Your email</label><input id="rvg-e" type="email" autocomplete="email" inputmode="email" placeholder="you@example.com" required>'+
'<label class="rvg__l" for="rvg-c">Your city</label><input id="rvg-c" type="text" autocomplete="address-level2" value="'+city.replace(/"/g,'')+'">'+
(SHARE?'<label class="rvg__org"><input type="checkbox" id="rvg-o"><span><b>Want updates from '+ORG+'?</b> Yes, share my email with '+ORG+' so they can contact me about '+(GD.getAttribute('data-ke-event-name')||'this event')+'. I will confirm by email first.</span></label><input type="text" name="website" id="rvg-hp" tabindex="-1" autocomplete="off" aria-hidden="true" style="position:absolute;left:-9999px;width:1px;height:1px;opacity:0">':'')+
'<p class="rvg__err" role="alert"></p><button type="submit" class="rvg__go"><span></span><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5 12h14M13 6l6 6-6 6"/></svg></button>'+
'<p class="rvg__fine">Free. One email a week until Christmas, and you can unsubscribe anytime. <a href="/privacy" target="_blank" rel="noopener">Privacy policy</a></p></form>'+
(ALLOW_SKIP?'<button type="button" class="rvg__skip">No thanks, just open the page</button>':'')+'</div>'+
'<div class="rvg__ok" role="status"><p class="rvg__k">You’re on the list</p><h2 class="rvg__h">Merry Christmas from Rally!</h2><p class="rvg__p"></p><a class="rvg__go" target="_blank" rel="noopener"><span></span><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5 12h14M13 6l6 6-6 6"/></svg></a></div></div></div>';
var sky=gate.querySelector('.rvg__sky');for(var i=0;i<18;i++){var f=document.createElement('i');f.style.left=Math.random()*100+'%';f.style.top=(-Math.random()*20)+'px';f.style.animationDuration=(4+Math.random()*5)+'s';f.style.animationDelay=(-Math.random()*6)+'s';f.style.width=f.style.height=(2+Math.random()*2.5)+'px';sky.appendChild(f)}
document.body.appendChild(gate);
gate.querySelector('.rvg__x').addEventListener('click',function(){ga('event_gate_close',{method:'x'});closeG()});
gate.addEventListener('click',function(e){if(e.target===gate){ga('event_gate_close',{method:'backdrop'});closeG()}});
gate.addEventListener('keydown',function(e){if(e.key==='Escape'){closeG();return}if(e.key!=='Tab')return;var f=[].filter.call(gate.querySelectorAll('input,button,a[href]'),function(x){return x.offsetParent!==null});if(!f.length)return;var a=f[0],z=f[f.length-1];if(e.shiftKey&&document.activeElement===a){e.preventDefault();z.focus()}else if(!e.shiftKey&&document.activeElement===z){e.preventDefault();a.focus()}});
var sk=gate.querySelector('.rvg__skip');if(sk)sk.addEventListener('click',function(){ga('event_gate_skip',{});try{sessionStorage.setItem('ke-skip','1')}catch(e){}var h=pend;closeG();if(h){var w=window.open(h,'_blank');if(w){try{w.opener=null}catch(x){}}else location.href=h}});
gate.querySelector('form').addEventListener('submit',submitG)}
function openG(href){if(!gate)buildGate();pend=href;lastF=document.activeElement;var h=host(href);
gate.classList.remove('done');gate.querySelector('.rvg__ask .rvg__k').textContent='Next stop: '+h;
gate.querySelector('.rvg__ask .rvg__h').textContent='Get free Christmas event emails';
gate.querySelector('.rvg__ask .rvg__p').textContent='New Christmas events for kids near you, hand-picked by Rally, once a week until Christmas. Then we’ll open '+h+'.';
gate.querySelector('.rvg__ask .rvg__go span').textContent='Continue to '+(ORG||h);
gate.hidden=false;requestAnimationFrame(function(){gate.classList.add('on')});document.documentElement.style.overflow='hidden';
setTimeout(function(){var i=gate.querySelector('#rvg-e');if(i)i.focus()},80);ga('event_gate_view',{link:h})}
function closeG(){if(!gate)return;gate.classList.remove('on');setTimeout(function(){gate.hidden=true},200);document.documentElement.style.overflow='';try{lastF&&lastF.focus()}catch(e){}}
function submitG(e){e.preventDefault();var f=e.target,em=f.querySelector('#rvg-e'),ci=f.querySelector('#rvg-c'),er=f.querySelector('.rvg__err'),bt=f.querySelector('.rvg__go'),ob=f.querySelector('#rvg-o'),v=(em.value||'').trim();
if(!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(v)){er.textContent='Please enter a valid email address.';em.setAttribute('aria-invalid','true');em.focus();return}
em.removeAttribute('aria-invalid');er.textContent='';bt.disabled=true;bt.querySelector('span').textContent='One moment…';
var cv=(ci&&ci.value||'').trim(),b=null;
try{b=window.__keGeo?window.__keGeo.payload({email:v,city:cv,lang:'en',country:'US',state:GD.getAttribute('data-ke-state'),source:'link pop-up',list:'christmas-events-for-kids-guide',event:pend||'',friend:false}):null}catch(x){b=null}
if(!b){b=new URLSearchParams();b.set('email',v);b.set('city',cv);b.set('lang','en');b.set('country','US');b.set('page',location.pathname);b.set('page_url',location.href.split('#')[0]);b.set('subscribe','rally-blog');b.set('source','link pop-up');b.set('list','christmas-events-for-kids-guide');b.set('event_link',pend||'');b.set('submitted_at',new Date().toISOString())}
b.set('gate_version','rvx-1');b.set('page_type','listed_event');b.set('org_event',GD.getAttribute('data-ke-event'));
if(SHARE&&ob&&ob.checked)orgLead(v,cv,ob.parentNode.textContent.replace(/\s+/g,' ').trim(),(f.querySelector('#rvg-hp')||{}).value);
/* the organizer share goes only to Rally's private backend (orgLead), never to the email list */
var fired=false;function done(){if(fired)return;fired=true;
try{localStorage.setItem(KEY,'email')}catch(x){}try{document.cookie=KEY+'=email;path=/;max-age=31536000;SameSite=Lax'}catch(x){}
try{document.dispatchEvent(new CustomEvent('ke:unlocked',{detail:'email'}))}catch(x){}
ga('event_gate_email',{org_share:SHARE?(ob&&ob.checked?'yes':'no'):'n/a'});ga('generate_lead',{lead_source:'listed_event_gate',value:1,currency:'USD'});
var ok=gate.querySelector('.rvg__ok');ok.querySelector('.rvg__p').textContent=(SHARE&&ob&&ob.checked?orgThanks()+' ':'')+'Your first Christmas events email arrives this week. Every link on Rally Takes the Train is now open on this device.';
var go=ok.querySelector('a');go.href=pend;go.querySelector('span').textContent='Open '+(ORG?ORG+'’s page':host(pend));go.addEventListener('click',function(){ga('event_gate_continue',{});setTimeout(closeG,150)},{once:true});
gate.classList.add('done');setTimeout(function(){go.focus()},60)}
try{fetch(HOOK,{method:'POST',mode:'no-cors',body:b,keepalive:true}).then(done,done)}catch(x){done()}setTimeout(done,2500)}
R.querySelectorAll('a[data-rvg]').forEach(function(a){a.addEventListener('click',function(e){if(e.defaultPrevented||e.button>0||e.metaKey||e.ctrlKey||unlocked())return;e.preventDefault();openG(a.href)})});
R.querySelectorAll('a[data-out]').forEach(function(a){a.addEventListener('click',function(){ga('listed_event_click',{link:a.getAttribute('data-out')})})});
}
/* borrow Rally's train scene that the site's collection hero builds, so the page does not carry a second copy */
var slot=R0.querySelector('[data-rvx-scene]');if(!slot){boot();return}
var n=0,t0=Date.now();(function look(){var sc=document.querySelector('.blog-item-top-wrapper .xn-scene');
if(sc){var cl=sc.cloneNode(true);sc.remove();slot.parentNode.replaceChild(cl,slot);boot();return}
if(Date.now()-t0>1500){slot.remove();boot();return}setTimeout(look,n++<20?50:150)})();
})();

(function(){
  if (window.__rttLb) return; window.__rttLb = 1;
  function init(){
    var links = [].slice.call(document.querySelectorAll('.rtt-gal a')); if (!links.length) return;
    var lb = document.createElement('div'); lb.className = 'rtt-lb'; lb.setAttribute('role','dialog'); lb.setAttribute('aria-modal','true'); lb.setAttribute('aria-label','Photo viewer');
    lb.innerHTML = '<div class="rtt-lb__box"><figure class="rtt-lb__fig"><img class="rtt-lb__img" alt=""><button type="button" class="rtt-lb__btn rtt-lb__prev" aria-label="Previous photo">&#8249;</button><button type="button" class="rtt-lb__btn rtt-lb__next" aria-label="Next photo">&#8250;</button><button type="button" class="rtt-lb__btn rtt-lb__x" aria-label="Close">&times;</button></figure><div class="rtt-lb__txt"><p class="rtt-lb__k"></p><h3 class="rtt-lb__t"></h3><p class="rtt-lb__p"></p></div></div>';
    document.body.appendChild(lb);
    var img = lb.querySelector('.rtt-lb__img'), fig = lb.querySelector('.rtt-lb__fig'), k = lb.querySelector('.rtt-lb__k'), t = lb.querySelector('.rtt-lb__t'), p = lb.querySelector('.rtt-lb__p');
    var cur = 0, last = null, ov = '';
    function show(i){
      cur = (i + links.length) % links.length; var a = links[cur], f = a.parentNode, th = a.querySelector('img');
      img.src = a.href; img.alt = th ? th.alt : '';
      var cap = f.querySelector('figcaption'), d = f.querySelector('.rtt-gal__d');
      k.textContent = (cur + 1) + ' of ' + links.length; t.textContent = cap ? cap.textContent : ''; p.textContent = d ? d.textContent : '';
      p.style.display = d ? '' : 'none';
      var n = links[(cur + 1) % links.length]; (new Image()).src = n.href;
    }
    function open(i){ last = document.activeElement; show(i); lb.classList.add('is-open'); ov = document.documentElement.style.overflow; document.documentElement.style.overflow = 'hidden'; lb.querySelector('.rtt-lb__x').focus(); }
    function close(){ lb.classList.remove('is-open'); document.documentElement.style.overflow = ov; img.removeAttribute('src'); if (last && last.focus) last.focus(); }
    links.forEach(function(a, i){ a.addEventListener('click', function(e){ if (e.metaKey || e.ctrlKey || e.shiftKey) return; e.preventDefault(); open(i); }); });
    lb.querySelector('.rtt-lb__x').onclick = close;
    lb.querySelector('.rtt-lb__prev').onclick = function(){ show(cur - 1); };
    lb.querySelector('.rtt-lb__next').onclick = function(){ show(cur + 1); };
    lb.addEventListener('click', function(e){ if (e.target === lb) close(); });
    document.addEventListener('keydown', function(e){ if (!lb.classList.contains('is-open')) return;
      if (e.key === 'Escape') close(); else if (e.key === 'ArrowLeft') show(cur - 1); else if (e.key === 'ArrowRight') show(cur + 1);
      else if (e.key === 'Tab') { var b = [].slice.call(lb.querySelectorAll('button')), ix = b.indexOf(document.activeElement); e.preventDefault(); b[(ix + (e.shiftKey ? -1 : 1) + b.length) % b.length].focus(); } });
    var sx = null; fig.addEventListener('touchstart', function(e){ sx = e.touches[0].clientX; }, {passive:true});
    fig.addEventListener('touchend', function(e){ if (sx === null) return; var dx = e.changedTouches[0].clientX - sx; if (Math.abs(dx) > 45) show(cur + (dx < 0 ? 1 : -1)); sx = null; });
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init); else init();
})();
</script>"""


def week_blocks(start, end):
    s, e = datetime.date.fromisoformat(start), datetime.date.fromisoformat(end)
    out, mon, n = [], s - datetime.timedelta(days=s.weekday()), 1
    while mon <= e:
        sat = mon + datetime.timedelta(days=5)
        days = "".join(f'<i class="{"on" if s <= mon + datetime.timedelta(days=k) <= e else ""}">{"MTWTFS"[k]}</i>' for k in range(6))
        out.append(f'<div class="rvx-week"><b>Week {n}</b><span>{MONTHS[mon.month-1][:3]} {mon.day} to {MONTHS[sat.month-1][:3]} {sat.day}</span><div class="rvx-days" aria-hidden="true">{days}</div></div>')
        mon, n = mon + datetime.timedelta(days=7), n + 1
    return "".join(out)


def grp(h, items):
    return (f'<div class="rvx-grp"><h3>{E(h)}</h3><ul class="rvx-tags" role="list">' + "".join(f"<li>{E(x)}</li>" for x in items) + '</ul></div>') if items else ""



# Brand marks for social links (simple single-path glyphs, drawn in currentColor)
SOC = {
 "facebook": ("Facebook", "#1877f2", '<path d="M14 8.5V6.8c0-.8.5-1 1-1h2V2.2h-2.8C11.1 2.2 10 4.4 10 6.5v2H7.6V12H10v9.8h4V12h2.8l.4-3.5z"/>'),
 "instagram": ("Instagram", "#c13584", '<path d="M12 2.2c-2.7 0-3 0-4.1.1-1 0-1.7.2-2.3.5-.7.3-1.2.6-1.8 1.2S2.9 5.1 2.6 5.8c-.2.6-.4 1.3-.5 2.3C2 9.1 2 9.4 2 12.1s0 3 .1 4c0 1 .2 1.7.5 2.3.3.7.6 1.2 1.2 1.8s1.1.9 1.8 1.2c.6.2 1.3.4 2.3.5 1 0 1.4.1 4.1.1s3 0 4-.1c1 0 1.7-.2 2.3-.5.7-.3 1.2-.6 1.8-1.2s.9-1.1 1.2-1.8c.2-.6.4-1.3.5-2.3 0-1 .1-1.4.1-4s0-3-.1-4.1c0-1-.2-1.7-.5-2.3-.3-.7-.6-1.2-1.2-1.8s-1.1-.9-1.8-1.2c-.6-.2-1.3-.4-2.3-.5-1 0-1.4-.1-4-.1zm0 1.8c2.6 0 2.9 0 4 .1.9 0 1.5.2 1.8.3.5.2.8.4 1.1.7s.6.7.7 1.1c.1.3.3.8.3 1.8.1 1 .1 1.3.1 4s0 2.9-.1 4c0 .9-.2 1.5-.3 1.8-.2.5-.4.8-.7 1.1s-.7.6-1.1.7c-.3.1-.8.3-1.8.3-1 .1-1.3.1-4 .1s-2.9 0-4-.1c-.9 0-1.5-.2-1.8-.3-.5-.2-.8-.4-1.1-.7s-.6-.7-.7-1.1c-.1-.3-.3-.8-.3-1.8-.1-1-.1-1.3-.1-4s0-2.9.1-4c0-.9.2-1.5.3-1.8.2-.5.4-.8.7-1.1s.7-.6 1.1-.7c.3-.1.8-.3 1.8-.3 1-.1 1.3-.1 4-.1zm0 3.1a4.9 4.9 0 1 0 0 9.8 4.9 4.9 0 0 0 0-9.8zm0 8.1a3.2 3.2 0 1 1 0-6.4 3.2 3.2 0 0 1 0 6.4zm6.3-8.3a1.2 1.2 0 1 1-2.3 0 1.2 1.2 0 0 1 2.3 0z"/>'),
 "youtube": ("YouTube", "#ff0033", '<path d="M23 7.2a3 3 0 0 0-2.1-2.1C19 4.6 12 4.6 12 4.6s-7 0-8.9.5A3 3 0 0 0 1 7.2C.5 9.1.5 12 .5 12s0 2.9.5 4.8a3 3 0 0 0 2.1 2.1c1.9.5 8.9.5 8.9.5s7 0 8.9-.5a3 3 0 0 0 2.1-2.1c.5-1.9.5-4.8.5-4.8s0-2.9-.5-4.8zM9.7 15.4V8.6l5.8 3.4z"/>'),
 "tiktok": ("TikTok", "#111111", '<path d="M16.6 2h-3.3v13.4a2.9 2.9 0 1 1-2-2.8V9.2a6.3 6.3 0 1 0 5.3 6.2V8.6a8.2 8.2 0 0 0 4.8 1.5V6.8a4.8 4.8 0 0 1-4.8-4.8z"/>'),
 "x": ("X", "#111111", '<path d="M17.8 2.5h3.3l-7.2 8.2 8.4 11.1h-6.6l-5.2-6.8-5.9 6.8H1.3l7.7-8.8L1 2.5h6.8l4.7 6.2zm-1.2 17.4h1.8L6.6 4.3H4.6z"/>'),
 "threads": ("Threads", "#111111", '<path d="M16.8 11.1l-.4-.2c-.2-3-1.9-4.8-4.7-4.8h-.1c-1.7 0-3.1.7-3.9 2l1.5 1c.6-.9 1.6-1.1 2.3-1.1 1 0 1.7.3 2.2.9.3.4.5 1 .6 1.7-.8-.1-1.7-.2-2.6-.1-2.6.2-4.3 1.7-4.2 3.8.1 1.1.6 2 1.5 2.6.8.5 1.8.7 2.8.7 1.4-.1 2.5-.6 3.2-1.6.6-.7.9-1.7 1-2.9.7.4 1.2.9 1.4 1.6.5 1.1.5 2.9-.9 4.3-1.2 1.2-2.7 1.8-5 1.8-2.5 0-4.4-.8-5.7-2.4C5.6 16.8 5 14.8 5 12.1s.6-4.7 1.8-6.2C8.1 4.3 10 3.5 12.5 3.5s4.5.8 5.8 2.4c.6.8 1.1 1.8 1.4 2.9l1.7-.5c-.4-1.4-1-2.6-1.8-3.6C18 2.7 15.6 1.7 12.5 1.7S7 2.7 5.4 4.7C4 6.5 3.2 9 3.2 12.1s.7 5.6 2.2 7.4c1.6 2 4 3 7.1 3 2.8 0 4.7-.7 6.3-2.3 2.1-2.1 2.1-4.7 1.4-6.3-.5-1.2-1.5-2.1-2.9-2.8zm-4.7 4.4c-1.1.1-2.3-.4-2.3-1.5-.1-.8.6-1.7 2.5-1.8h.7c.7 0 1.3.1 1.9.2-.2 2.4-1.4 3-2.8 3.1z"/>'),
 "linkedin": ("LinkedIn", "#0a66c2", '<path d="M4.98 3.5a2.5 2.5 0 1 1 0 5 2.5 2.5 0 0 1 0-5zM3 9.8h4v11.7H3zm6.5 0h3.8v1.6h.1c.5-1 1.8-2 3.8-2 4 0 4.8 2.6 4.8 6.1v6H18v-5.3c0-1.3 0-2.9-1.8-2.9s-2 1.4-2 2.8v5.4h-4z"/>'),
}

def soc_key(name, url):
    n = (name + " " + url).lower()
    for k, host in (("facebook", "facebook.com"), ("instagram", "instagram.com"), ("youtube", "youtube.com"), ("tiktok", "tiktok.com"), ("threads", "threads.net"), ("linkedin", "linkedin.com")):
        if host in n or k in name.lower(): return k
    if "x.com" in n or "twitter.com" in n or name.strip().lower() in ("x", "twitter"): return "x"
    return None

def soc_icons(links, org, cls):
    out = []
    for name, u in links:
        k = soc_key(name, u)
        if not k: continue
        label, col, path = SOC[k]
        out.append(f'<li><a class="rvx-soc" style="--b:{col}" href="{E(u)}" target="_blank" rel="noopener" data-out="social" aria-label="{E(org)} on {label} (opens in a new tab)">'
                   f'<svg viewBox="0 0 24 24" aria-hidden="true" focusable="false" fill="currentColor">{path}</svg><span>{label}</span></a></li>')
    return f'<ul class="{cls}" role="list">' + "".join(out) + '</ul>' if out else ""

LANG_CODES = {"english": "en", "spanish": "es", "swedish": "sv", "french": "fr", "german": "de", "chinese": "zh", "vietnamese": "vi", "korean": "ko", "japanese": "ja", "portuguese": "pt", "italian": "it", "tagalog": "tl", "hmong": "hmn", "somali": "so", "arabic": "ar", "asl": "ase", "american sign language": "ase"}

def faq_all(p):
    """FAQ data: the page FAQ plus the AI Search Boost Quick Answers, without repeating a question."""
    out, seen = [], set()
    for q, a in list(p.get("quick") or []) + list(p.get("faq") or []):
        k = re.sub(r"[^a-z0-9]+", " ", q.lower()).strip()
        if k not in seen:
            seen.add(k); out.append([q, a])
    return out


def quick_box(p):
    """AI Search Boost: short, direct answers near the top of the page, where people and AI look first."""
    qa = p.get("quick") or []
    if not qa:
        return ""
    items = "".join(f"<div><dt>{E(q)}</dt><dd>{E(a)}</dd></div>" for q, a in qa)
    return (f'<section class="rvx-sec rvx-quick" aria-labelledby="h-quick"><h2 id="h-quick">Quick answers</h2>'
            f'<dl>{items}</dl></section>')


def build(path):
    ev = json.load(open(path))
    s, p = ev["survey"], ev["page"]
    url = f"{SITE}/christmas-events/{ev['slug']}"
    primary = next(c for c in p["cities"] if c.get("primary"))
    year = s["start_date"][:4]
    sd = datetime.date.fromisoformat(s["start_date"])
    endx = (datetime.date.fromisoformat(s["end_date"]) + datetime.timedelta(days=1)).isoformat()
    tel = ""  # organizer contact info is never posted (owner rule 2026-11-13)
    s = {**s, "public_contact": ""}
    tel_disp = f"({tel[-10:-7]}) {tel[-7:-4]}-{tel[-4:]}" if tel.startswith("+1") and len(tel) == 12 else tel
    free = str(s.get("cost", "")).lower() == "free"
    tzs = []
    for l in p["locations"]:
        if l.get("tz") and l["tz"] not in tzs: tzs.append(l["tz"])
    multi_tz = len(tzs) > 1
    site_host = re.sub(r"^https?://(www\.)?", "", s["ticket_link"]).split("/")[0]
    tlink = add_utm(s["ticket_link"], ev["slug"], "event")
    # host website link (audit 2026-11-21): the host's own site is a visible link; Eventbrite is only ever the tickets button
    _org = (p.get("organizer_url") or "").strip()
    if re.search(r"eventbrite\.|ticketleap|ticketmaster|facebook\.com|instagram\.com", _org): _org = ""
    if _org and _org.rstrip("/") != s["ticket_link"].rstrip("/"):
        _oh = re.sub(r"^https?://(www\.)?", "", _org).split("/")[0]
        host_cta = (f'<a class="rvx-cta" href="{E(add_utm(_org, ev["slug"], "event"))}" target="_blank" rel="noopener" data-out="website" data-ke-skip data-rvg>'
                    f'Visit the host\'s website<small>{E(s["organizer_name"])}, {E(_oh)}</small><span class="sr"> (opens in a new tab)</span></a>')
    elif _org:
        host_cta = (f'<a class="rvx-cta" href="{E(tlink)}" target="_blank" rel="noopener" data-out="details" data-ke-skip data-rvg>'
                    f'See dates and details<small>from {E(site_host)}</small><span class="sr"> (opens in a new tab)</span></a>')
    else:
        host_cta = ""
    desc = p.get("ld_description") or (p["hero_sub"] + " " + p["about"][1])

    # ---------- schema ----------
    places = []
    for l in p["locations"]:
        addr = {"@type": "PostalAddress", "addressLocality": l["city"], "addressRegion": s["venue_state"], "addressCountry": "US"}
        if l["street"]: addr["streetAddress"] = l["street"]
        if l["zip"]: addr["postalCode"] = l["zip"]
        pl = {"@type": "Place", "name": l["name"] if l["street"] else f"{s['organizer_name']}, {l['area']}", "address": addr}
        if l.get("geo") and len(l["geo"]) == 2:
            pl["geo"] = {"@type": "GeoCoordinates", "latitude": l["geo"][0], "longitude": l["geo"][1]}
        pl["hasMap"] = maps(", ".join(x for x in [l.get("street"), l["city"], s["venue_state"], l.get("zip")] if x))
        feats = list(p.get("access") or []) + list(p.get("amenities") or [])
        if feats: pl["amenityFeature"] = [{"@type": "LocationFeatureSpecification", "name": f, "value": True} for f in feats]
        places.append(pl)
    avail = "https://schema.org/LimitedAvailability" if "fast" in s["availability"].lower() else "https://schema.org/InStock"
    vf = {"validFrom": s["on_sale"]} if s.get("on_sale") else {}
    offers = [{"@type": "Offer", "name": a, "price": b[1:].split(" ")[0].replace(",", ""), "priceCurrency": s.get("currency", "USD"), "availability": avail, "url": s["ticket_link"], **vf} for a, b in p["price_rows"] if re.match(r"^\$[0-9.,]+( |$)", b)]
    if free and not offers:
        offers = [{"@type": "Offer", "name": "Admission", "price": "0", "priceCurrency": s.get("currency", "USD"), "availability": avail, "url": s["ticket_link"], **vf}]
    langs = [LANG_CODES.get(x.strip().lower(), x.strip()) for x in re.split(r"[;,]| and ", s.get("languages") or "English") if x.strip()]
    performers = [{"@type": (x[1] if isinstance(x, list) and len(x) > 1 else "PerformingGroup"), "name": (x[0] if isinstance(x, list) else x)} for x in (p.get("performers") or [])] or {"@type": "Organization", "name": s["organizer_name"]}
    extra = {}
    if p.get("sponsors"): extra["sponsor"] = [{"@type": "Organization", "name": x} for x in p["sponsors"]]
    if s.get("doors"): extra["doorTime"] = f"{s['start_date']}T{s['doors']}:00{tzoff(s['start_date'], s['doors'], s['timezone'])}"
    if p.get("series"): extra["superEvent"] = {"@type": "Event", "name": p["series"]["name"], **({"url": p["series"]["url"]} if p["series"].get("url") else {})}
    if p.get("capacity"): extra["maximumAttendeeCapacity"] = int(p["capacity"])
    mode = "https://schema.org/OfflineEventAttendanceMode"
    if p.get("livestream"):
        mode = "https://schema.org/MixedEventAttendanceMode"
        places = places + [{"@type": "VirtualLocation", "url": p["livestream"]}]
    ev_imgs = p.get("schema_images") or ([ph["src"] for ph in p["photos"]] if p.get("photos") else IMG_SET)
    prim = {"@type": "ImageObject", "url": ev_imgs[0]}
    if not p.get("schema_images") and not p.get("photos"): prim.update({"width": 1600, "height": 900})
    graph = [
        {"@type": "WebPage", "@id": url, "url": url, "name": p["title"], "description": p["description"], "inLanguage": ev["lang"],
         "isPartOf": {"@id": f"{SITE}/#website"}, "breadcrumb": {"@id": url + "#breadcrumb"}, "mainEntity": {"@id": url + "#event"},
         "datePublished": ev["published"], "primaryImageOfPage": prim, "publisher": {"@id": f"{SITE}/#org"}},
        {"@type": "BreadcrumbList", "@id": url + "#breadcrumb", "itemListElement": [
            {"@type": "ListItem", "position": 1, "name": "Christmas Events for Kids", "item": f"{SITE}/christmas-events-for-kids"},
            {"@type": "ListItem", "position": 2, "name": p["state"]["name"], "item": SITE + p["state"]["url"]},
            {"@type": "ListItem", "position": 3, "name": primary["name"], "item": SITE + primary["url"]},
            {"@type": "ListItem", "position": 4, "name": p["h1"], "item": url}]},
        {"@type": "Event", "@id": url + "#event", "name": p["h1"], "description": desc, "url": url,
         "startDate": (f"{s['start_date']}T{s['start_time']}:00{tzoff(s['start_date'], s['start_time'], s['timezone'])}" if s.get("start_time") else s["start_date"]), "endDate": (f"{s['end_date']}T{s['end_time']}:00{tzoff(s['end_date'], s['end_time'], s['timezone'])}" if s.get("end_time") and s.get("start_time") else s["end_date"]),
         "eventStatus": "https://schema.org/EventScheduled", "eventAttendanceMode": mode,
         "location": places, "image": ev_imgs, "inLanguage": (ev["lang"] if len(langs) == 1 else langs), **({"isAccessibleForFree": free} if str(s.get("cost", "")).lower() in ("free", "paid") else {}), **({"typicalAgeRange": f"{s['min_age']}-{s['max_age'] if s.get('max_age') is not None else ''}"} if s.get("min_age") is not None else {}),
         "audience": {"@type": "PeopleAudience", "audienceType": s["audience"], **({"suggestedMinAge": s["min_age"], **({"suggestedMaxAge": s["max_age"]} if s.get("max_age") is not None else {})} if s.get("min_age") is not None else {})},
         "organizer": {"@type": "Organization", "name": s["organizer_name"], **({"url": _org} if _org else {}), **({"sameAs": [u for _, u in p["social"]]} if p.get("social") else {}), **({"email": s["public_contact"]} if s.get("public_contact") else {}), **({"telephone": tel} if tel else {})},
         "performer": performers, **({"offers": offers} if offers else {}), **extra,
         **({"eventSchedule": {"@type": "Schedule", "startDate": s["start_date"], "endDate": s["end_date"], "repeatFrequency": "P1W",
                               "byDay": [f"https://schema.org/{d}" for d in p["schedule_by_day"]], "scheduleTimezone": s["timezone"]}} if p.get("schedule_by_day") else {})},
        {"@type": "FAQPage", "@id": url + "#faq", "mainEntity": [{"@type": "Question", "name": q, "acceptedAnswer": {"@type": "Answer", "text": a}} for q, a in faq_all(p)]},
    ]
    if p.get("video"):
        v = p["video"]
        graph.append({"@type": "VideoObject", "@id": url + "#video", "name": v["name"], "description": v["desc"],
                      "thumbnailUrl": v["thumb"], "uploadDate": v["date"], "embedUrl": v["embed"],
                      **({"contentUrl": v["content"]} if v.get("content") else {}), "publisher": {"@id": f"{SITE}/#org"}})
    _evn = next(n for n in graph if n["@type"] == "Event")
    for _k, _v in (p.get("ld_extra") or {}).items():
        if _k not in _evn: _evn[_k] = _v
    graph[0].update({"about": {"@id": url + "#event"}, 
                     **({"speakable": {"@type": "SpeakableSpecification", "cssSelector": ["h1", ".rvx-quick dl"]}} if p.get("quick") else {})})
    ld = json.dumps({"@context": "https://schema.org", "@graph": graph}, ensure_ascii=False).replace("</", "<\\/")
    evdata = {"slug": ev["slug"], "name": p["h1"], "start": s["start_date"], "endx": endx, "where": p["where_short"], "when": p["when_short"], "desc": p["hero_sub"], "url": url}

    # calendar links
    # calendar: a timed event on the first date, start time to end time (or one hour later when no end time is known)
    _allday = not s.get("start_time")
    _st = datetime.datetime.fromisoformat(f"{s['start_date']}T{s.get('start_time') or '00:00'}").replace(tzinfo=ZoneInfo(s["timezone"]))
    _et = None
    _cal = p.get("cal")  # optional override: {"date","start","end","loc"} for the add-to-calendar entry
    if _cal:
        _st = datetime.datetime.fromisoformat(f"{_cal['date']}T{_cal['start']}").replace(tzinfo=ZoneInfo(s["timezone"]))
        _et = datetime.datetime.fromisoformat(f"{_cal['date']}T{_cal['end']}").replace(tzinfo=ZoneInfo(s["timezone"]))
    elif s.get("cal_end") or s.get("end_time"):
        _et = datetime.datetime.fromisoformat(f"{s['start_date']}T{s.get('cal_end') or s['end_time']}").replace(tzinfo=ZoneInfo(s["timezone"]))
        if _et <= _st: _et = None
    if _et is None: _et = _st + datetime.timedelta(hours=1)
    _u = lambda d: d.astimezone(datetime.timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    cal_s, cal_e = _u(_st), _u(_et)
    if _allday:
        _d0 = datetime.date.fromisoformat(s["start_date"]); cal_s, cal_e = _d0.strftime("%Y%m%d"), (_d0 + datetime.timedelta(days=1)).strftime("%Y%m%d")
    _l0 = p["locations"][(_cal or {}).get("loc", 0)]
    cal_loc = ", ".join(x for x in [_l0.get("name") if _l0.get("name") != _l0.get("street") else "", _l0.get("street"), (_l0.get("city", "") + ", " + s["venue_state"] + (" " + _l0["zip"] if _l0.get("zip") else ""))] if x) if _l0.get("street") else p["where_short"]
    _cd = (p["hero_sub"] + " " + p["cal_note"]) if p.get("cal_note") else p["hero_sub"]
    evdata["desc"] = _cd
    g = "https://calendar.google.com/calendar/render?" + urlencode({"action": "TEMPLATE", "text": p["h1"], "dates": f"{cal_s}/{cal_e}", "ctz": s["timezone"], "details": f"{_cd} {url}", "location": cal_loc})
    o = "https://outlook.live.com/calendar/0/deeplink/compose?" + urlencode({"path": "/calendar/action/compose", "rru": "addevent", "subject": p["h1"], "startdt": (s["start_date"] if _allday else _st.isoformat()), "enddt": ((datetime.date.fromisoformat(s["start_date"]) + datetime.timedelta(days=1)).isoformat() if _allday else _et.isoformat()), **({"allday": "true"} if _allday else {}), "location": cal_loc, "body": f"{_cd} {url}"})
    evdata["ds"], evdata["de"], evdata["where"] = cal_s, cal_e, cal_loc
    if _allday: evdata["ds"], evdata["de"] = "", ""
    if p.get("cal_days"):
        evdata["rr"] = f"FREQ=DAILY;COUNT={int(p['cal_days'])}"
        g += "&" + urlencode({"recur": "RRULE:" + evdata["rr"]})

    crumbs = "".join(f'<li><a href="{E(h)}">{E(n)}</a></li>' for n, h in [("Christmas Events", "/christmas-events-for-kids"), (p["state"]["name"], p["state"]["url"]), (primary["name"], primary["url"])])
    chips = "".join(f"<li>{E(c)}</li>" for c in p["hero_chips"])
    pills = "".join(f'<span class="rvx-pill">{E(x)}</span>' for x in p["card_pills"])
    pills += {"paid": '<span class="rvx-pill paid">Paid</span>', "free": '<span class="rvx-pill paid">Free</span>'}.get(str(s.get("cost", "")).lower(), "")
    pills += '<span class="rvx-pill">Confirmed</span>'
    facts = "".join(f'<li>{ico(i)}<span>{E(a)}<small>{E(b)}</small></span></li>' for i, a, b in p["facts2"])
    about = "".join(f"<p>{E(x)}</p>" for x in p["about"])
    tbl = "".join(f"<dt>{E(a)}</dt><dd>{E(b)}</dd>" for a, b in p["table"])
    qs = []
    if tel: qs.append(f'{"Text" if p.get("phone_sms", True) else "Call"} <a href="{"sms" if p.get("phone_sms", True) else "tel"}:{E(tel)}" data-out="sms">{tel_disp}</a>')
    if s.get("public_contact"): qs.append(f'{"email" if tel else "Email"} <a href="mailto:{E(s["public_contact"])}" data-out="email">{E(s["public_contact"])}</a>')
    if qs:
        tbl += f'<dt>Questions</dt><dd>{" or ".join(qs)}</dd>'
    tbl += f'<dt>Confirmed</dt><dd>On the host\'s own site, checked <time datetime="{ev["checked"]}">{nice_date(ev["checked"])}</time></dd>'
    price = "".join(f'<tr><th scope="row">{E(a)}</th><td{' class="long"' if len(b) > 16 else ''}>{E(b)}</td></tr>' for a, b in p["price_rows"])
    locs = ""
    for li_i, l in enumerate(p["locations"]):
        if l.get("street"):
            q = (f'{l["name"]}, ' if l["name"] != l["street"] else '') + f'{l["street"]}, {l["city"]}, {s["venue_state"]} {l["zip"]}'
            head = "" if len(p["locations"]) == 1 and l["area"] == l["name"] else f'<b>{E(l["area"])}{" · " + E(l["tz"]) + " time" if multi_tz and l.get("tz") != tzs[0] else ""}</b>'
            locs += (f'<li id="loc-{li_i}">{head}{E(l["name"])}<br>{E(l["street"])}<br>{E(l["city"])}, {E(s["venue_state"])} {E(l["zip"])}<br>'
                     f'<a href="{E(maps(q))}" target="_blank" rel="noopener" data-out="map">Directions<span class="sr"> to {E(l["name"])} (opens in a new tab)</span></a></li>')
        else:
            locs += f'<li id="loc-{li_i}"><b>{E(l["area"])}</b>{E(l["city"])}, {E(s["venue_state"])}<br>{E(l.get("note", "Exact address is shown when you register"))}.</li>'
    social = ""
    soc_top = soc_icons(p.get("social") or [], s["organizer_name"], "rvx-socs rvx-socs--sm")
    if p.get("social") and soc_top:
        social = (f'<section class="rvx-sec" aria-labelledby="h-follow"><h2 id="h-follow">Follow {E(s["organizer_name"])}</h2>'
                  + soc_icons(p["social"], s["organizer_name"], "rvx-socs")
                  + (f'<p class="rvx-note">{E(p["social_note"])}</p>' if p.get("social_note") else "") + '</section>')
    # Good to know: every remaining survey answer (accessibility, performers, sponsors, weather plan)
    gtk = ""
    if p.get("access"):
        gtk += '<div class="rvx-gk"><h3>Accessibility</h3><ul class="rvx-ticks" role="list">' + "".join(f"<li>{ico('check')}{E(x)}</li>" for x in p["access"]) + '</ul>' + (f'<p class="rvx-note">{E(p["access_note"])}</p>' if p.get("access_note") else "") + '</div>'
    if p.get("performers"):
        gtk += f'<div class="rvx-gk"><h3>{E(p.get("performers_h") or "Who you will see")}</h3><ul class="rvx-ticks" role="list">' + "".join(f"<li>{ico('star')}{E(x[0] if isinstance(x, list) else x)}</li>" for x in p["performers"]) + '</ul></div>'
    if p.get("weather"):
        gtk += f'<div class="rvx-gk"><h3>If the weather turns</h3><p>{E(p["weather"])}</p></div>'
    if p.get("sponsors") or p.get("sponsors_line"):
        gtk += f'<div class="rvx-gk"><h3>Sponsors</h3><p>{E(p.get("sponsors_line") or ", ".join(p["sponsors"]) + ".")}</p></div>'
    good = f'<section class="rvx-sec" aria-labelledby="h-good"><h2 id="h-good">Good to know</h2><div class="rvx-gks">{gtk}</div></section>' if gtk else ""
    gallery = ""
    if p.get("photos"):
        def _fig(ph):
            wh = f' width="{ph["w"]}" height="{ph["h"]}"' if ph.get("w") else ""
            cap = f'<figcaption>{E(ph["cap"])}</figcaption>' if ph.get("cap") else ""
            desc = f'<span class="rtt-gal__d">{E(ph["desc"])}</span>' if ph.get("desc") else ""
            return (f'<figure><a href="{E(ph["src"])}" target="_blank" rel="noopener">'
                    f'<img src="{E(ph["src"])}" alt="{E(ph["alt"])}"{wh} loading="lazy" decoding="async"></a>{cap}{desc}</figure>')
        hint = E(p.get("photos_hint") or "Tap any photo to see it larger, with the story behind it.")
        gallery = ('<section class="rvx-sec" aria-labelledby="h-photos"><h2 id="h-photos">Photos</h2>'
                   '<div class="rtt-gal">' + "".join(_fig(ph) for ph in p["photos"]) + '</div>'
                   f'<p class="rtt-gal__hint">{hint}</p>'
                   + (f'<p class="rvx-note">{E(p["photos_note"])}</p>' if p.get("photos_note") else "") + '</section>')
    video_html = ""
    if p.get("video"):
        v = p["video"]
        video_html = ('<section class="rvx-sec" aria-labelledby="h-video"><h2 id="h-video">' + E(v.get("heading") or "Watch") + '</h2>'
                      '<div class="rvx-video"><iframe src="https://www.youtube-nocookie.com/embed/' + E(v["id"]) + '?rel=0" title="' + E(v["name"]) + '" loading="lazy" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen referrerpolicy="strict-origin-when-cross-origin"></iframe></div>'
                      + (f'<p class="rvx-note">{E(v["note"])}</p>' if v.get("note") else "") + '</section>')
    faq = "".join(f"<details><summary>{E(q)}</summary><p>{E(a)}</p></details>" for q, a in p["faq"])
    more = "".join(f'<li><a href="{E(c["url"])}">Christmas events in {E(c["name"])}<span>Every event we found for kids in {E(c["name"])}</span></a></li>' for c in p["cities"])
    more += f'<li><a href="{E(p["state"]["url"])}">All of {E(p["state"]["name"])}<span>Christmas events across the state</span></a></li>'
    more += '<li><a href="/coloring-pages">Christmas coloring pages<span>Free to print, starring Rally</span></a></li>'

    # Rally's route: one station per city, with Rally's train from the hero riding the track (positions set per event in the JSON)
    route = ""
    rc = p.get("route_cities") or []
    if len(rc) > 1:
        P = [(c["x"], c["y"]) for c in rc]
        d = f"M{P[0][0]} {P[0][1]}"
        for i in range(len(P) - 1):  # Catmull-Rom to cubic Bezier
            p0 = P[i - 1] if i else P[i]; p1 = P[i]; p2 = P[i + 1]; p3 = P[i + 2] if i + 2 < len(P) else P[i + 1]
            c1 = (p1[0] + (p2[0] - p0[0]) / 6, p1[1] + (p2[1] - p0[1]) / 6); c2 = (p2[0] - (p3[0] - p1[0]) / 6, p2[1] - (p3[1] - p1[1]) / 6)
            d += f" C{c1[0]:.0f} {c1[1]:.0f} {c2[0]:.0f} {c2[1]:.0f} {p2[0]} {p2[1]}"
        sts = ""
        for c in rc:
            idx = [i for i, l in enumerate(p["locations"]) if l["city"] == c["city"]]
            areas = [p["locations"][i]["area"].split(" / ")[0] for i in idx]
            sub = (f'{len(idx)} classes: ' + ", ".join(areas)) if len(idx) > 1 else (p["locations"][idx[0]]["name"] if idx else "")
            x, y = c["x"], c["y"]; below = c.get("label", "below" if y < 120 else "above") == "below"
            ty = y + 44 if below else y - 44
            sts += (f'<g class="st" tabindex="0" role="button" data-locs="{" ".join("loc-%d" % i for i in idx)}" aria-label="{E(c["city"])}: show {"addresses" if len(idx) > 1 else "address"}">'
                    f'<circle cx="{x}" cy="{y}" r="22" fill="#f2c14e" opacity=".18"/><circle class="o" cx="{x}" cy="{y}" r="11" fill="#f2c14e" stroke="#172235" stroke-width="3"/><circle cx="{x}" cy="{y}" r="4" fill="#172235"/>'
                    f'<text x="{x}" y="{ty}" text-anchor="middle" fill="#fff" font-family="Fraunces,Georgia,serif" font-weight="600" font-size="22">{E(c["city"])}</text>'
                    f'<text x="{x}" y="{ty + 20}" text-anchor="middle" fill="#d9e2f0" font-family="Nunito,sans-serif" font-weight="700" font-size="13">{E(sub)}</text></g>')
        stars = "".join(f'<circle cx="{(i*137)%900}" cy="{(i*61)%120+6}" r="{1 + (i%3)*0.4:.1f}" fill="#fff" opacity="{0.35 + (i%4)*0.12:.2f}"/>' for i in range(28))
        route = (f'<div class="rvx-route"><svg viewBox="0 0 900 300" role="img" aria-label="Map of the class locations in {E(", ".join(c["city"] for c in rc))}">{stars}'
                 f'<path d="M0 300 C200 250 380 270 520 255 S780 230 900 250 V300Z" fill="#2c4368" opacity=".6"/>'
                 f'<path id="rvx-rt" d="{d}" fill="none" stroke="#5b6b8c" stroke-width="10" stroke-linecap="round"/>'
                 f'<path d="{d}" fill="none" stroke="#c9b8a6" stroke-width="2.5" stroke-dasharray="3 10" stroke-linecap="round"/>'
                 f'<g class="rvx-rt-train"></g>{sts}</svg><p>Not to scale. Tap a city to see its addresses.</p></div>')
    calc = ""
    if p.get("price_calc"):
        pc = p["price_calc"]
        calc = (f'<div class="rvx-calc" data-calc=\'{json.dumps(pc)}\'><div><label>{E(pc["label_kids"])}</label><div class="rvx-step"><button type="button" data-d="k-" aria-label="One fewer child">&minus;</button><output data-k>1</output><button type="button" data-d="k+" aria-label="One more child">+</button></div></div>'
                f'<div><label>{E(pc["label_babies"])}</label><div class="rvx-step"><button type="button" data-d="b-" aria-label="One fewer baby">&minus;</button><output data-b>0</output><button type="button" data-d="b+" aria-label="One more baby">+</button></div></div>'
                f'<div class="rvx-calc__t" aria-live="polite"><small>Your family pays</small><b data-tot>${pc["tiers"][0]}</b></div></div>')
    nearby = ""
    if p.get("nearby_events"):
        cards = "".join(f'<li><a href="{E(n["url"])}"><span class="tg">{E(n["tag"])}</span><b>{E(n["name"])}</b><span>{E(n["when"])} · {E(n["where"])}</span><em>{E(n["near"])}</em></a></li>' for n in p["nearby_events"])
        nh = p.get("nearby_h") or ("Free Christmas events near the classes" if len(p["locations"]) > 1 else "More free Christmas events nearby")
        ni = p.get("nearby_when") or ("during the session" if len(p["locations"]) > 1 else "this season")
        nearby = (f'<section class="rvx-sec" aria-labelledby="h-nearby"><h2 id="h-nearby">{E(nh)}</h2>'
                  f'<p>Free events in {E(primary["name"])} {E(ni)}, from our <a href="{E(primary["url"])}">list of the best Christmas events for kids in {E(primary["name"])}</a>. Every date is checked on the host\'s own site.</p>'
                  f'<ul class="rvx-near" role="list">{cards}</ul></section>')
    if p.get("dates_list"):
        dates_html = '<ul class="rvx-dl" role="list">' + "".join(f'<li><b>{E(r[0])}</b><span>' + (f'<a href="{E(r[2])}" target="_blank" rel="noopener" data-out="session">{E(r[1])}</a>' if len(r) > 2 else E(r[1])) + '</span></li>' for r in p["dates_list"]) + '</ul>'
    else:
        dates_html = f'<div class="rvx-weeks">{week_blocks(s["start_date"], s["end_date"])}</div>'
    where_h = p.get("where_h") or ("Where the classes are" if len(p["locations"]) > 1 else "Where it is")
    paid = ev.get("plan", "free") in ("featured", "sponsored")
    share = paid or LEADS_LIVE
    gate_open = (f'<div class="rvx-gated" data-ke-lang="en" data-ke-country="US" data-ke-state="{E(s["venue_state"])}" data-ke-event="{E(ev["slug"])}" '
                 f'data-ke-event-name="{E(p["h1"])}" data-ke-org="{E(s["organizer_name"])}" data-ke-org-share="{"1" if share else "0"}" data-ke-org-paid="{"1" if paid else "0"}" data-ke-leads="{E(LEADS_ENDPOINT)}" data-ke-org-host="{E(org_host(s["ticket_link"]))}">')
    org_form = ""
    if share:
        org_form = (f'<section class="rvx-orgf" aria-labelledby="h-orgf"><h2 id="h-orgf">Get updates from {E(s["organizer_name"])}</h2>'
                    f'<p>Spaces, schedule changes and reminders for {E(p["h1"])}, sent by {E(s["organizer_name"])}.</p>'
                    f'<form novalidate><label class="sr" for="rvx-orgf-e">Your email</label><input id="rvx-orgf-e" type="email" autocomplete="email" placeholder="you@example.com" required>'
                    f'<input type="text" name="website" tabindex="-1" autocomplete="off" aria-hidden="true" style="position:absolute;left:-9999px;width:1px;height:1px;opacity:0">'
                    f'<label class="rvx-orgf__c"><input type="checkbox" required><span>Share my email with {E(s["organizer_name"])} so they can contact me about {E(p["h1"])}. I will confirm by email first.</span></label>'
                    f'<button type="submit">Send me updates</button><p class="rvx-orgf__err" role="alert"></p>'
                    f'<p class="rvx-orgf__fine">We email you a link to confirm first, and nothing is shared until you do. Then Rally Takes the Train shares your email with {E(s["organizer_name"])}, who uses it under their own privacy policy and must let you unsubscribe from every email. '
                    f'Unconfirmed emails are deleted after 7 days. See our <a href="/privacy#organizer-updates">privacy policy</a>.</p></form></section>')
    SCENE_HTML = '<div data-rvx-scene hidden></div>' if BORROW else _SCENE
    body = f"""<link rel="preconnect" href="https://fonts.googleapis.com"><link href="https://fonts.googleapis.com/css2?family=Fraunces:ital,opsz,wght@0,9..144,500;0,9..144,600;1,9..144,500&family=Nunito:wght@400;600;700;800&display=swap" rel="stylesheet">
<style>{CSS}</style>
<script type="application/ld+json">{ld}</script>
{gate_open}
<article class="rvx" id="rvx" data-city="{E(primary["name"])}" data-ev="{E(json.dumps(evdata))}">
<div class="rvx-hero">
<canvas aria-hidden="true"></canvas>
<button type="button" class="rvx-snow" aria-pressed="false">Pause the snow</button>
<nav aria-label="Breadcrumb"><ol class="rvx-crumb">{crumbs}</ol></nav>
<p class="rvx-eyebrow">{E(p["eyebrow"])}</p>
<h2 class="rvx-htitle">{E(p["h1"])} <em>{year}</em></h2>
<p class="rvx-sub">{E(p["hero_sub"])}</p>
<ul class="rvx-chips" role="list"><li class="rvx-live" data-rvx-live hidden></li>{chips}</ul>
<a class="rvx-btn" href="{E(tlink)}" target="_blank" rel="noopener" data-out="register" data-ke-skip data-rvg>{E(p["register_label"])} {ico("arrow")}<span class="sr"> (opens in a new tab)</span></a>
<p class="rvx-micro">{E(p.get("booking_line") or ("Booking is with " + s["organizer_name"] + "."))} Rally Takes the Train doesn't sell tickets or take a cut.</p>
{SCENE_HTML}
</div>

<section class="rvx-list" aria-labelledby="rvx-name">
<div class="rvx-top"><div class="rvx-date" aria-hidden="true"><span>{MONTHS[sd.month-1][:3]}</span><b>{sd.day}</b><span>{DAYS[sd.weekday()][:3]}</span></div>
<div><div class="rvx-pills">{pills}</div><h2 id="rvx-name">{E(p["h1"])}</h2><p class="rvx-by">{E(p["by"])}</p>{soc_top}</div></div>
<ul class="rvx-facts" role="list">{facts}</ul>
<div class="rvx-about"><p class="rvx-about__h">About this event</p>{about}
<p class="rvx-tip"><b>Parent tip:</b> {E(p["tip"])}</p>
{grp("What kids can do", p.get("kids_do"))}
{grp("On site", p.get("on_site"))}
<dl class="rvx-tbl">{tbl}</dl></div>
{host_cta}
<div class="rvx-calw"><button type="button" class="rvx-cal" aria-haspopup="true" aria-expanded="false">Add to calendar</button>
<div class="rvx-calm" hidden><a data-p="google" href="{E(g)}" target="_blank" rel="noopener">Google Calendar</a><a data-p="ics" href="#">Apple / Outlook (.ics)</a><a data-p="outlook" href="{E(o)}" target="_blank" rel="noopener">Outlook.com</a></div></div>
<button type="button" class="rvx-share">Share {E(p["h1"])}<small>Send it to a friend with little ones</small></button>
</section>

{quick_box(p)}
{org_form}
{video_html}
{gallery}
<section class="rvx-sec" aria-labelledby="h-dates"><h2 id="h-dates">{"Date" if len(p.get("dates_list") or [0, 0]) == 1 else "Dates"}</h2>
{dates_html}
<p class="rvx-note">{E(p["schedule_note"])}</p></section>

<section class="rvx-sec" aria-labelledby="h-cost"><h2 id="h-cost">Prices</h2>
<table class="rvx-price"><caption class="sr">Prices</caption><tbody>{price}</tbody></table>
{calc}
<p class="rvx-note">{E(p["price_note"])}</p></section>

<section class="rvx-sec" aria-labelledby="h-where"><h2 id="h-where">{E(where_h)}</h2>
{route}
<ul class="rvx-locs" role="list">{locs}</ul>
<p class="rvx-note">{E(p["locations_note"])}</p></section>

{good}
{social}
{"" if p.get("no_gift") else (p.get("gift_html") or GIFT_HTML)}
<section class="rvx-sec" aria-labelledby="h-faq"><h2 id="h-faq">Questions</h2><div class="rvx-faq">{faq}</div></section>

<section class="rvx-sec rvx-badge rvx-claim" aria-labelledby="h-ver"><img class="rvx-claim__img" src="{WREATH}?format=300w" alt="" width="120" height="120" loading="lazy"><div>
<h2 id="h-ver">Is this your event?</h2>
<p>We listed {E(p["h1"])} from {E(s["organizer_name"] if s["organizer_name"].endswith("'s") else (s["organizer_name"] + ("'" if s["organizer_name"].endswith("s") else "'s")))} public website and checked the details on {nice_date(ev["checked"])}. It is not verified by the organizer yet. If you run it, <a href="/verify-your-christmas-event" data-out="verify">verify it for free</a> to confirm the details, get Rally's Verified badge and see how many families view it.</p></div></section>

{nearby}
<section class="rvx-sec" aria-labelledby="h-more"><h2 id="h-more">More near {E(primary["name"])}</h2><ul class="rvx-more" role="list">{more}</ul></section>

<div class="rvx-org"><p>Organize a Christmas event for kids? <a href="/verify-your-christmas-event">Verify it for free</a> and get the Verified badge on your page.</p></div>
</article>
</div>
{JS}"""
    body = body.replace('__TRACKER__', TRACKER_JS)
    nodash(body)

    # ---------- card for city pages (matches city page event card markup) ----------
    c = p["card"]
    cal = json.dumps({"n": p["h1"], "l": p["where_short"], "u": url, "m": maps(primary["name"] + ", " + s["venue_state"]), "d": [[s["start_date"], s["start_time"], "", ""]]}, ensure_ascii=False)
    eid = "ev-" + ev["slug"]
    card = f"""<section class="rtt-pe-ride rtt-pe-ride--verified" id="{eid}" aria-labelledby="{eid}-h" data-xf-ty="{E(p["filter"]["ty"])}" data-xf-fl="{E(p["filter"]["fl"])}" data-xf-town="{E(p["filter"]["town"])}" data-cal="{E(cal)}">
<div class="rtt-xh"><div class="rtt-xt" aria-hidden="true"><span class="rtt-xt__m">{c["date_badge"][0]}</span><span class="rtt-xt__d">{c["date_badge"][1]}</span><span class="rtt-xt__s">{c["date_badge"][2]}</span></div><div><p class="rtt-pe-ride__op"><span class="rtt-pe-tag rtt-pe-tag--lic">{E(c["tag"])}</span><span class="rtt-pe-tag rtt-pe-tag--ver"><img src="{WREATH}?format=100w" alt="" width="20" height="20" loading="lazy" style="width:20px;height:20px;border-radius:50%;vertical-align:-5px;margin-right:5px">Verified</span></p>
<h3 id="{eid}-h">{E(p["h1"])}</h3></div></div>
<ul class="rtt-xc" role="list"><li><span class="rtt-xc__sr">When: </span><span class="rtt-xc__v">{E(c["when"])}</span></li><li><span class="rtt-xc__sr">Where: </span><span class="rtt-xc__v">{E(c["where"])}</span></li><li><span class="rtt-xc__sr">Cost: </span><span class="rtt-xc__v">{E(c["cost"])}</span></li><li><span class="rtt-xc__sr">Ages: </span><span class="rtt-xc__v">{E(c["ages"])}</span></li></ul>
<a class="rtt-pe-ride__book" href="/christmas-events/{ev["slug"]}"><span class="rtt-xb"><span>See the verified listing</span><small>{E(c["link_small"])}</small></span></a>
</section>"""
    nodash(card)

    meta = {"post_title": p["h1"], "url_slug": ev["slug"], "collection": "/christmas-events", "seo_title": p["title"],
            "seo_description": p["description"], "excerpt": p["description"], "event_page_url": url,
            "city_pages_to_update": [c["url"] for c in p["cities"]], "flags": ev.get("flags", [])}
    nodash(json.dumps(meta, ensure_ascii=False))

    od = os.path.join(os.path.dirname(os.path.abspath(__file__)), "out", ev["slug"]); os.makedirs(od, exist_ok=True)
    open(os.path.join(od, "page.html"), "w").write(body)
    open(os.path.join(od, "card.html"), "w").write(card)
    json.dump(meta, open(os.path.join(od, "meta.json"), "w"), indent=2, ensure_ascii=False)
    open(os.path.join(od, "preview.html"), "w").write(
        f'<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>{E(p["title"])}</title>'
        f'<style>body{{margin:0;background:#fff}}.mh{{display:flex;justify-content:space-between;align-items:center;padding:16px 28px;border-bottom:1px solid #eee;font:600 14px Nunito,sans-serif}}.mh b{{font:italic 600 22px Fraunces,serif;color:#b8443a}}.wrap{{padding:28px 20px 80px}}</style></head>'
        f'<body><div class="mh"><b>Rally Takes the Train</b><span>Christmas Events · Our Story</span></div><div class="wrap">{body}</div></body></html>')
    print(od, len(body), "bytes")


if __name__ == "__main__":
    for f in sys.argv[1:]:
        build(f)
