#!/usr/bin/env python3
"""AI Search Boost: draft the Quick Answers for one event from facts already in its JSON.

Usage: python3 quick_answers.py events/<slug>.json            (writes page.quick, prints a report)
       python3 quick_answers.py events/<slug>.json --dry      (prints only)

Every answer comes from a field that is already in the event JSON (checked with the organizer).
Nothing is guessed: a question whose fact is missing is skipped and listed under "missing".
Answers repeat the event name and city, so each one still makes sense when an AI quotes it alone.
"""
import json, re, sys, datetime
from locale_rules import Loc

def clean(s):
    s = re.sub(r"\s+", " ", str(s or "")).strip()
    return s.replace("—", ",").replace("–", " to ")

def nice(d, L=None):
    m = re.match(r"(\d{4})-(\d{2})-(\d{2})", str(d))
    if not m: return str(d)
    if L is not None: return L.date(datetime.date(int(m.group(1)), int(m.group(2)), int(m.group(3))))
    months = "January February March April May June July August September October November December".split()
    return f"{months[int(m.group(2)) - 1]} {int(m.group(3))}, {m.group(1)}"

def tbl(p, key):
    for k, v in p.get("table") or []:
        if str(k).strip().lower() == key:
            return clean(v)
    return ""

def draft(ev):
    p, s = ev["page"], ev.get("survey", {})
    L = Loc(ev)
    name = clean(p["h1"])
    city = clean(s.get("venue_city") or (p.get("locations") or [{}])[0].get("city", ""))
    st = clean(s.get("venue_state"))
    place = f"{city}, {st}" if city and st else city
    q, missing = [], []

    when = clean(p.get("when_long")) or clean((p.get("card") or {}).get("when"))
    if not when and p.get("dates_list"):
        when = "; ".join(f"{r[0]}, {r[1]}" if r[1] else r[0] for r in p["dates_list"])
    verb = "runs" if re.search(r" to (Mon|Tue|Wed|Thu|Fri|Sat|Sun)", when) else "is on"
    if when:
        q.append([f"When is {name} in {city} in 2026?", f"{name} in {city} {verb} {when}." if re.match(r"^(Mon|Tue|Wed|Thu|Fri|Sat|Sun)", when) else f"{name} in {city}: {when}."])
    else:
        missing.append("date and time")

    locs = p.get("locations") or []
    addr = []
    for l in locs:
        parts = [clean(l.get("name") or l.get("area")), clean(l.get("street")), " ".join(x for x in [clean(l.get("city")) + ("," if st else ""), st, clean(l.get("zip"))] if x).replace(", ", ",").rstrip(",").replace(",", ", ")]
        a = ", ".join(x for x in parts if x)
        if a: addr.append(a)
    if addr:
        q.append([f"Where is {name}?", f"{name} is at {addr[0]}." if len(addr) == 1 else f"{name} runs at {len(addr)} places: " + "; ".join(addr) + "."])
    else:
        missing.append("address")

    rows = p.get("price_rows") or []
    note = clean(p.get("price_note"))
    if rows or note:
        free = all(str(v).strip().lower().startswith("free") for _, v in rows) if rows else False
        price = "; ".join(f"{clean(k)}: {clean(v)}" for k, v in rows)
        if free:
            q.append([f"Is {name} free?", f"Yes, {name} is free. " + (note if note else "")])
        else:
            q.append([f"How much does {name} cost?", f"{name} prices: {price}." + (" " + note if note else "")])
    else:
        missing.append("price")

    ages = clean((p.get("card") or {}).get("ages_long"))
    lo, hi = s.get("min_age"), s.get("max_age")
    if ages or lo is not None:
        try: rng = f" The {L.w('organizer')} suggests ages {int(lo)} to {int(hi)}." if lo is not None and hi not in (None, "") and int(hi) <= 17 else ""
        except (TypeError, ValueError): rng = ""
        q.append([f"Is {name} good for kids?", (f"{name}: {ages[0].lower() + ages[1:]}." if ages else f"{name} welcomes families.") + rng])
    else:
        missing.append("ages")

    tk = tbl(p, "tickets") or clean(p.get("booking_line"))
    if tk:
        q.append([f"Do you need tickets for {name}?", f"Tickets for {name}: {tk[0].lower() + tk[1:]}" + ("" if tk.endswith(".") else ".")])
    pk = tbl(p, "parking") or clean(s.get("parking"))
    if pk:
        q.append([f"Where do you park for {name}?", f"Parking for {name}: {pk[0].lower() + pk[1:]}" + ("" if pk.endswith(".") else ".")])
    else:
        missing.append("parking")
    se = tbl(p, "setting") or clean(s.get("indoor_outdoor"))
    if se:
        q.append([f"Is {name} indoors or outdoors?", f"{name} is {se[0].lower() + se[1:]}" + ("" if se.endswith(".") else ".")])

    org = clean(s.get("organizer_name"))
    if org:
        host = f"{name} is run by its own {L.w('organizers')}." if org.lower() == name.lower() else f"{name} is hosted by {org}."
        q.append([f"Who runs {name}?", f"{host} The {L.w('organizer')} verified these details with Rally Takes the Train on {nice(ev.get('checked',''), L)}."])
    for x in q:
        x[1] = re.sub(r"\s+", " ", x[1]).replace("..", ".").strip()
    return q, missing

if __name__ == "__main__":
    path = sys.argv[1]; dry = "--dry" in sys.argv
    ev = json.load(open(path))
    q, missing = draft(ev)
    bad = [a for _, a in q if "—" in a or "–" in a]
    for a, b in q: print("Q:", a, "\n   A:", b)
    print("missing:", ", ".join(missing) or "none", "| dashes:", len(bad))
    if not dry:
        ev["page"]["quick"] = q
        ev["page"]["quick_missing"] = missing
        json.dump(ev, open(path, "w"), indent=2, ensure_ascii=False)
        print("written to", path)
