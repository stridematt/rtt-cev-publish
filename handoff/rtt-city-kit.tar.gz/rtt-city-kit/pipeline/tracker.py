"""Shared visit and click tracker for verified event pages and city page cards.
No personal data: a random id that changes every day, counted once per kind per event per day on the server."""
from urllib.parse import urlsplit, urlunsplit, parse_qsl, urlencode

def add_utm(url, slug, content):
    """Tag outbound organizer links so Rally visits show up in the organizer's own analytics."""
    p = urlsplit(url)
    q = [(k, v) for k, v in parse_qsl(p.query, keep_blank_values=True) if not k.startswith("utm_")]
    q += [("utm_source", "rallytakesthetrain.com"), ("utm_medium", "referral"),
          ("utm_campaign", "christmas-events-2026"), ("utm_content", f"{slug}--{content}")]
    return urlunsplit((p.scheme, p.netloc, p.path or "/", urlencode(q), p.fragment))

def org_host(url):
    return urlsplit(url).hostname.lower().removeprefix("www.")

TRACKER_JS = r"""(function(){if(window.__rttT)return;var T=window.__rttT={reg:[]};
function vid(){try{var d=new Date().toISOString().slice(0,10),o=JSON.parse(localStorage.getItem('rtt_vid')||'{}');if(o.d!==d||!/^[a-z0-9]{16}$/.test(o.id||'')){var a=new Uint8Array(16);crypto.getRandomValues(a);o={d:d,id:Array.prototype.map.call(a,function(b){return'abcdefghijklmnopqrstuvwxyz0123456789'[b%36]}).join('')};localStorage.setItem('rtt_vid',JSON.stringify(o))}return o.id}catch(e){return''}}
function bot(){return navigator.webdriver||/bot|crawl|spider|slurp|headless|lighthouse|pagespeed|preview/i.test(navigator.userAgent||'')}
T.send=function(url,o){if(bot()||!/^https:\/\/script\.google\.com\//.test(url||''))return;o.vid=vid();if(!o.vid)return;o.action='track';var body=JSON.stringify(o);try{if(navigator.sendBeacon&&navigator.sendBeacon(url,new Blob([body],{type:'text/plain;charset=utf-8'})))return}catch(x){}try{fetch(url,{method:'POST',mode:'no-cors',body:body,keepalive:true,credentials:'omit',referrerPolicy:'no-referrer'})}catch(x){}};
function host(h){return String(h||'').toLowerCase().replace(/^www\./,'')}
T.add=function(r){T.reg.push(r)};
function onClick(e){if(e.type==='auxclick'&&e.button!==1)return;var a=e.target&&e.target.closest&&e.target.closest('a[href]');if(!a)return;var h;try{h=host(new URL(a.href,location.href).hostname)}catch(x){return}
setTimeout(function(){if(e.defaultPrevented)return;T.reg.forEach(function(r){if(r.host&&h===r.host){var k=a.getAttribute('data-out');T.send(r.url,{event:r.event,kind:'click',link:(k==='register'||k==='details')?k:'site',src:a.closest('.rvg')?'gate':r.src})}})},0)}
document.addEventListener('click',onClick,true);document.addEventListener('auxclick',onClick,true)})();"""
