"""Marquee pill enforcement for the "Biggest events" block (nav#rtt-big).

The marquee is assembled by hand, so this module guarantees one thing by code:
a pick that is a Verified event (one in the event roster) shows the "Verified"
tag; every other pick shows "Confirmed". It is deterministic and self-healing,
so it can run on every publish and on the daily recount.

Verified set: derived from the event roster (events/*.json). Each event's slug is
the marquee anchor key (tiles link to #ev-<slug>). Adding a new verified event JSON
automatically extends the set, so new pages stay correct with no code change.

CLI:
  python3 marquee.py keys                 # print the verified keys, one per line
  python3 marquee.py enforce page.html    # write corrected HTML to stdout; report to stderr
"""
import json, os, re, sys, glob

HERE = os.path.dirname(os.path.abspath(__file__))
EVENTS_DIR = os.environ.get("RTT_EVENTS_DIR", os.path.join(HERE, "events"))

CHK = "✓"
PILL = '<span class="rb-k"><span aria-hidden="true">' + CHK + ' </span>{label}</span>'
CONFIRMED = PILL.format(label="Confirmed")
VERIFIED = PILL.format(label="Verified")
_PILL_RE = re.compile(
    r'<span class="rb-k"><span aria-hidden="true">' + re.escape(CHK) +
    r' </span>(?:Confirmed|Verified)</span>'
)


def verified_keys(events_dir=None):
    """The set of marquee anchor keys (#ev-<key>) that are Verified events."""
    events_dir = events_dir or EVENTS_DIR
    keys = set()
    for f in glob.glob(os.path.join(events_dir, "*.json")):
        try:
            d = json.load(open(f, encoding="utf-8"))
        except Exception:
            continue
        slug = d.get("slug")
        if slug:
            keys.add(slug)
    return keys


def page_verified_keys(html):
    """Verified event keys present on the page itself: the data-rvc-ev slug of every
    verified detail card (class rtt-pe-ride--verified). This makes enforcement
    self-contained, so a page stays correct with no external list."""
    keys = set()
    for m in re.finditer(r'<section[^>]*class="[^"]*rtt-pe-ride--verified[^"]*"[^>]*>', html):
        tag = m.group(0)
        mm = re.search(r'data-rvc-ev="([a-z0-9-]+)"', tag)
        if mm:
            keys.add(mm.group(1))
    return keys


def enforce(html, keys=None):
    """Set every marquee pick tile's pill to Verified when its #ev-<key> is in
    keys, else Confirmed. Only touches tiles inside nav#rtt-big. Returns
    (new_html, changes)."""
    base = verified_keys() if keys is None else set(keys)
    keys = base | page_verified_keys(html)
    mstart = html.find('id="rtt-big"')
    if mstart < 0:
        return html, 0
    lt = html.rfind("<nav", 0, mstart)
    block_start = lt if lt >= 0 else mstart
    close = html.find("</nav>", mstart)
    block_end = close + len("</nav>") if close >= 0 else len(html)
    block = html[block_start:block_end]

    counter = {"n": 0}

    def fix_tile(m):
        key = m.group("key")
        tile = m.group(0)
        want = VERIFIED if key in keys else CONFIRMED
        new_tile, n = _PILL_RE.subn(lambda _m: want, tile, count=1)
        if n and new_tile != tile:
            counter["n"] += 1
            return new_tile
        return tile

    block = re.sub(
        r'<li\b(?:(?!</li>).)*?href="#ev-(?P<key>[a-z0-9-]+)"(?:(?!</li>).)*?</li>',
        fix_tile,
        block,
        flags=re.S,
    )
    return html[:block_start] + block + html[block_end:], counter["n"]


def pill(is_verified):
    return VERIFIED if is_verified else CONFIRMED


if __name__ == "__main__":
    if len(sys.argv) >= 2 and sys.argv[1] == "keys":
        for k in sorted(verified_keys()):
            print(k)
    elif len(sys.argv) >= 3 and sys.argv[1] == "enforce":
        h = open(sys.argv[2], encoding="utf-8").read()
        nh, c = enforce(h)
        sys.stderr.write("marquee pills corrected: %d\n" % c)
        sys.stdout.write(nh)
    else:
        sys.stderr.write(__doc__)
        sys.exit(1)
