#!/usr/bin/env python3
"""Listed event pages: add Quick Answers (listed wording, never says the organizer verified) and
schema extras taken from the city page's Event node (offers, typicalAgeRange, sameAs).
Usage: python3 enrich_listed.py <events_dir> <city_page.html>"""
import json, re, sys, glob
from quick_answers import draft, clean, nice

def city_nodes(path):
    h = open(path).read(); out = {}
    for m in re.finditer(r'<script type="application/ld\+json">(.*?)</script>', h, re.S):
        try: d = json.loads(m.group(1))
        except Exception: continue
        for n in (d.get("@graph", [d]) if isinstance(d, dict) else d):
            if n.get("@type") == "Event" and "#ev-" in str(n.get("url", "")):
                out[n["url"].split("#", 1)[1]] = n
    return out

def poss(x): return x if x.endswith("'s") else x + ("'" if x.endswith("s") else "'s")

def main(d, city):
    nodes = city_nodes(city); rep = []
    for f in sorted(glob.glob(d + "/*.json")):
        ev = json.load(open(f)); p, s = ev["page"], ev["survey"]
        q, missing = draft(ev)
        org = clean(s.get("organizer_name")); name = clean(p["h1"])
        for x in q:
            if x[0].startswith("Who runs"):
                host = f"{name} is run by its own organizers." if org.lower() == name.lower() else f"{name} is hosted by {org}."
                x[1] = f"{host} Rally Takes the Train checked these details on {poss(org)} own website on {nice(ev['checked'])}. Check there before you go, since hosts sometimes change plans."
        if "ages" in missing:
            ages = clean((p.get("card") or {}).get("ages") or p.get("ages_short"))
            if ages:
                i = next((k for k, x in enumerate(q) if x[0].startswith("Do you need")), len(q))
                q.insert(i, [f"Is {name} good for kids?", f"{name}: {ages[0].lower() + ages[1:]}" + ("" if ages.endswith(".") else ".")])
                missing.remove("ages")
        site = f"{poss(org)} own website" if org else "the host's own website"
        su = dict(p.get("table") or []).get("Sign-up", "")
        for x in q:
            if x[0].startswith(f"Is {name} free?"):
                x[1] = f"Yes, {name} is free to attend, based on {site}. Rally Takes the Train doesn't sell tickets."
            elif x[0] == f"Is {name} good for kids?" and x[1].startswith(name + ": "):
                t = x[1][len(name) + 2:].rstrip(".")
                if re.match(r"(?i)all ages", t):
                    x[1] = f"Yes. {name} is for all ages" + (", " + t[8:].lstrip(" ,;") if len(t) > 8 else "") + "."
                elif re.match(r"(?i)family event$", t):
                    x[1] = f"Yes. {name} is a family event."
            elif x[0].startswith("Do you need tickets"):
                lead = {"Required ahead of time": "Yes, sign-up is required ahead of time.", "Recommended": "Signing up ahead is recommended."}.get(su, "")
                x[1] = (lead + " " if lead else "") + f"Tickets, reservations and any sign-up for {name} are on {site}. Rally Takes the Train doesn't sell tickets."
        topics = [("When is", "When is"), ("Where is", "Where is"), ("How much", "How much"), ("Is " + name + " free", "How much"),
                  ("Is " + name + " good for kids", "What ages"), ("Do you need tickets", "Do you need")]
        for x in q:
            for qp, fp in topics:
                if x[0].startswith(qp):
                    m = next((fq for fq, _ in (p.get("faq") or []) if fq.startswith(fp)), None)
                    if m and not x[0].startswith("Is " + name + " free"): x[0] = m
            rows = p.get("price_rows") or []
            if x[0].startswith("How much") and len(rows) == 1 and clean(rows[0][1]):
                k, v = clean(rows[0][0]), clean(rows[0][1]).rstrip(".")
                x[1] = f"{k} for {name}: {v[0].lower() + v[1:]}. Prices are set by {org} and can change. Rally Takes the Train doesn't sell tickets."
        if not clean(str(s.get("cost", ""))):
            q = [x for x in q if not (x[0].startswith("How much") or x[0].startswith("Is " + name + " free"))]
            p["price_rows"] = [r for r in (p.get("price_rows") or []) if clean(r[1])]
        for x in q:
            if x[0].startswith("What ages") and x[1].startswith("Yes. "): x[1] = x[1][5:]
            x[1] = re.sub(r"\s+", " ", x[1]).replace("..", ".").strip()
            assert "—" not in x[1] + x[0] and "–" not in x[1] + x[0], f
        p["quick"], p["quick_missing"] = q, missing
        n = nodes.get(ev.get("source_card") or "")
        if n:
            p["ld_extra"] = {k: n[k] for k in ("offers", "typicalAgeRange", "sameAs") if n.get(k)}
        free = str(s.get("cost", "")).lower() == "free"
        if not free and not (p.get("ld_extra") or {}).get("offers") and not any(re.match(r"^\$[0-9.,]+( |$)", b) for _, b in p.get("price_rows") or []):
            p.setdefault("ld_extra", {})["offers"] = {"@type": "Offer", "url": s["ticket_link"], "priceCurrency": s.get("currency", "USD"), "availability": "https://schema.org/InStock"}
        json.dump(ev, open(f, "w"), indent=2, ensure_ascii=False)
        rep.append((ev["slug"], len(q), sorted((p.get("ld_extra") or {}).keys())))
    for r in rep: print(*r)

if __name__ == "__main__":
    main(sys.argv[1], sys.argv[2])
