import re, json, html
import sys
s=open(sys.argv[1]).read()
cards=re.findall(r'<section class="rtt-pe-ride" id=.*?</section>',s,re.S)
def txt(x): return html.unescape(re.sub(r'<[^>]+>','',x)).strip()
out=[]
for c in cards:
    d={}
    d['id']=re.search(r'id="(ev-[^"]+)"',c).group(1)
    for k in ['ty','fl','town']:
        m=re.search(r'data-xf-%s="([^"]*)"'%k,c); d[k]=html.unescape(m.group(1)) if m else ''
    m=re.search(r'data-cal="([^"]*)"',c); d['cal']=json.loads(html.unescape(m.group(1))) if m else None
    d['badge']=[txt(x) for x in re.findall(r'<span class="rtt-xt__[mds]">(.*?)</span>',c)]
    d['tags']=[txt(x) for x in re.findall(r'<span class="rtt-pe-tag[^"]*">(.*?)</span>',c)]
    d['name']=txt(re.search(r'<h3[^>]*>(.*?)</h3>',c,re.S).group(1))
    vals={}
    for li in re.findall(r'<li>(.*?)</li>',re.search(r'<ul class="rtt-xc".*?</ul>',c,re.S).group(0),re.S):
        km=re.search(r'rtt-xc__sr">(.*?)</span>',li) or re.search(r'rtt-xc__i" title="([^"]+)"',li)
        k=txt(km.group(1)).rstrip(': ').strip()
        v=re.search(r'rtt-xc__v">(.*)</span>',li,re.S).group(1); vals[k]=txt(re.sub(r'<span class="rtt-map__sr">.*?</span>','',v))
    d['facts']=vals
    b=re.search(r'<div class="rtt-xd__b">(.*?)</div></details>',c,re.S)
    body=b.group(1) if b else ''
    d['paras']=[txt(x) for x in re.findall(r'<p>(.*?)</p>',body,re.S)]
    m=re.search(r'<p class="rtt-ev__tip">(.*?)</p>',body,re.S); d['tip']=txt(m.group(1)).replace('Parent tip:','').strip() if m else ''
    dl={}
    for dt,dd in re.findall(r'<dt>(.*?)</dt><dd>(.*?)</dd>',body,re.S):
        a=re.search(r'href="([^"]+)"',dd); dl[txt(dt)]={'t':txt(re.sub(r'<span class="rtt-(?:sr|map__sr)">.*?</span>','',dd)),'href':html.unescape(a.group(1)) if a else ''}
    d['dl']=dl
    m=re.search(r'<a class="rtt-pe-ride__book" href="([^"]+)"',c); d['book']=html.unescape(m.group(1)) if m else ''
    m=re.search(r'<span class="rtt-xb"><span>(.*?)</span><small>(.*?)</small>',c); d['book_label']=[txt(m.group(1)),txt(m.group(2))] if m else []
    d['other_tags']=re.findall(r'<details class="rtt-xd[^"]*"><summary>.*?<span>(.*?)</span>',c)
    d['verified']=('rtt-pe-ride--verified' in c[:300]) or d['book'].startswith('/christmas-events/')
    out.append(d)
json.dump(out,open(sys.argv[2],'w'),indent=1,ensure_ascii=False)
import collections
print(collections.Counter(tuple(sorted(d['facts'].keys())) for d in out))
print(collections.Counter(tuple(sorted(d['dl'].keys())) for d in out))
print(collections.Counter(d['town'] for d in out))
print(sum(1 for d in out if not d['book']), 'no book')
print(collections.Counter(len(d['paras']) for d in out))
