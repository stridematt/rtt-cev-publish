#!/usr/bin/env python3
"""Share image (1200x630) for a verified event page: the page hero, captured from preview.html.
Usage: python3 og.py <slug>   (run build_event.py first). Writes out/<slug>/og.png."""
import os, sys
from playwright.sync_api import sync_playwright

slug = sys.argv[1]
od = os.path.join(os.path.dirname(os.path.abspath(__file__)), "out", slug)
with sync_playwright() as pw:
    b = pw.chromium.launch()
    pg = b.new_page(viewport={"width": 1200, "height": 900}, device_scale_factor=1)
    pg.goto("file://" + os.path.join(od, "preview.html"))
    pg.wait_for_timeout(2500)
    pg.add_style_tag(content=".wrap{padding:0!important}.rvx-snow,.rvx-crumb,[data-rvx-live]{display:none!important}.rvx{max-width:1200px!important}.rvx-hero{border-radius:0!important;min-height:630px}")
    pg.wait_for_timeout(300)
    box = pg.locator(".rvx-hero").bounding_box()
    pg.screenshot(path=os.path.join(od, "og.png"), clip={"x": box["x"], "y": box["y"], "width": 1200, "height": 630})
    b.close()
print(os.path.join(od, "og.png"))
